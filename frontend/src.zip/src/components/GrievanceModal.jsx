import React, { useState } from 'react';
import { X, Send, ShieldAlert, CheckCircle2, FileText } from 'lucide-react';

export const GrievanceModal = ({ isOpen, onClose }) => {
  const [complaintName, setComplaintName] = useState('Rajesh Kumar Verma');
  const [refId, setRefId] = useState('');
  const [category, setCategory] = useState('Payment Delay in DBT');
  const [details, setDetails] = useState('');
  const [ticketId, setTicketId] = useState(null);

  if (!isOpen) return null;

  const handleSubmitGrievance = (e) => {
    e.preventDefault();
    const newTicket = `CPGRAMS-2026-${Math.floor(100000 + Math.random() * 900000)}`;
    setTicketId(newTicket);
  };

  const handleDone = () => {
    setTicketId(null);
    setDetails('');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-stoneWarm-950/60 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl border border-stoneWarm-200 shadow-modal max-w-lg w-full p-6">
        
        <div className="flex justify-between items-center border-b border-stoneWarm-200 pb-3 mb-4">
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 rounded-lg bg-ochre-100 text-ochre-800 flex items-center justify-center font-bold">
              !
            </div>
            <div>
              <h3 className="text-base font-bold text-stoneWarm-900 font-display">
                Public Grievance Redressal (CPGRAMS)
              </h3>
              <p className="text-[11px] text-stoneWarm-500">
                Direct Escalation to Department Nodal Officers
              </p>
            </div>
          </div>
          <button onClick={onClose} className="text-stoneWarm-400 hover:text-stoneWarm-700">
            <X className="w-5 h-5" />
          </button>
        </div>

        {!ticketId ? (
          <form onSubmit={handleSubmitGrievance} className="space-y-3.5 text-xs">
            <div>
              <label className="block font-semibold text-stoneWarm-700 mb-1">Complainant / Citizen Name</label>
              <input
                type="text"
                required
                value={complaintName}
                onChange={(e) => setComplaintName(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-stoneWarm-50 border border-stoneWarm-300 text-stoneWarm-900 text-xs focus:ring-1 focus:ring-brand-500"
              />
            </div>

            <div>
              <label className="block font-semibold text-stoneWarm-700 mb-1">Scheme Application Reference ID (Optional)</label>
              <input
                type="text"
                placeholder="e.g. SS-2026-89412"
                value={refId}
                onChange={(e) => setRefId(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-stoneWarm-50 border border-stoneWarm-300 text-stoneWarm-900 text-xs focus:ring-1 focus:ring-brand-500 font-mono"
              />
            </div>

            <div>
              <label className="block font-semibold text-stoneWarm-700 mb-1">Grievance Category</label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-stoneWarm-50 border border-stoneWarm-300 text-stoneWarm-900 text-xs"
              >
                <option value="Payment Delay in DBT">Payment Delay / DBT Installment Not Received</option>
                <option value="Wrongful Desk Rejection">Dispute on Eligibility / Document Rejection</option>
                <option value="Aadhaar Seeding Issue">Bank Account NPCI Mapping Issue</option>
                <option value="Field Officer Misconduct">Field Inspection / Verification Delay</option>
                <option value="Other Technical Glitch">Portal / DigiLocker Technical Glitch</option>
              </select>
            </div>

            <div>
              <label className="block font-semibold text-stoneWarm-700 mb-1">Detailed Description of Grievance</label>
              <textarea
                rows={4}
                required
                placeholder="Please state the specific dates, branch names, and nature of the issue..."
                value={details}
                onChange={(e) => setDetails(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-stoneWarm-50 border border-stoneWarm-300 text-stoneWarm-900 text-xs focus:ring-1 focus:ring-brand-500"
              ></textarea>
            </div>

            <div className="flex justify-end space-x-2 pt-2 border-t border-stoneWarm-200">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 rounded-xl text-stoneWarm-700 hover:bg-stoneWarm-100 font-semibold"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-5 py-2 rounded-xl bg-brand-600 hover:bg-brand-700 text-white font-semibold shadow-subtle flex items-center space-x-1"
              >
                <Send className="w-3.5 h-3.5" />
                <span>Submit Grievance</span>
              </button>
            </div>
          </form>
        ) : (
          <div className="text-center py-4 space-y-4">
            <div className="w-14 h-14 rounded-full bg-brand-100 text-brand-700 flex items-center justify-center mx-auto">
              <CheckCircle2 className="w-8 h-8" />
            </div>
            <h4 className="text-lg font-bold text-stoneWarm-900">Grievance Registered Successfully</h4>
            <p className="text-xs text-stoneWarm-600">
              Your grievance has been assigned to the District Nodal Officer. Expected resolution within 7 working days.
            </p>
            <div className="p-3 bg-stoneWarm-50 rounded-xl border border-stoneWarm-200 font-mono text-sm font-bold text-brand-800">
              Ticket ID: {ticketId}
            </div>
            <button
              onClick={handleDone}
              className="px-6 py-2.5 rounded-xl bg-brand-600 hover:bg-brand-700 text-white text-xs font-semibold"
            >
              Done
            </button>
          </div>
        )}

      </div>
    </div>
  );
};
