import React, { useState } from 'react';
import { 
  Sparkles, 
  ArrowRight, 
  ArrowLeft, 
  CheckCircle2, 
  Banknote, 
  Building, 
  ShieldCheck, 
  RotateCcw,
  Layers,
  ChevronRight
} from 'lucide-react';
import { SCHEMES_DATA } from '../data/mockData';

export const EligibilityCalculator = ({ onApplyScheme }) => {
  const [step, setStep] = useState(1);
  const [calcData, setCalcData] = useState({
    age: 32,
    gender: 'Male', // 'Male', 'Female', 'Other'
    state: 'Madhya Pradesh',
    category: 'OBC',
    occupation: 'Farmer',
    annualIncome: 220000,
    hasLand: true,
    isStudent: false
  });

  const [matchedResults, setMatchedResults] = useState(null);

  const handleCalculate = () => {
    // Filter matching schemes based on user input
    const matches = SCHEMES_DATA.filter((s) => {
      // Age
      if (calcData.age < s.eligibility.minAge || calcData.age > s.eligibility.maxAge) {
        return false;
      }
      // Gender
      if (s.eligibility.gender !== 'Any' && s.eligibility.gender !== calcData.gender) {
        return false;
      }
      // Income
      if (calcData.annualIncome > s.eligibility.maxIncome) {
        return false;
      }
      // State
      if (s.state !== 'All India' && s.state !== calcData.state) {
        return false;
      }
      // Category
      if (!s.eligibility.caste.includes('All') && !s.eligibility.caste.includes(calcData.category)) {
        return false;
      }
      return true;
    });

    setMatchedResults(matches);
    setStep(4); // Results step
  };

  const handleReset = () => {
    setStep(1);
    setMatchedResults(null);
  };

  return (
    <section className="py-12 bg-gradient-to-b from-stoneWarm-100/60 to-stoneWarm-50 min-h-[600px]">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center space-x-1.5 px-3 py-1 rounded-full bg-ochre-100 text-ochre-800 text-xs font-semibold mb-2">
            <Sparkles className="w-3.5 h-3.5" />
            <span>AI-Assisted Eligibility Engine</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-display font-extrabold text-stoneWarm-900">
            Check Your Government Scheme Eligibility
          </h2>
          <p className="text-stoneWarm-600 text-xs sm:text-sm mt-1 max-w-xl mx-auto">
            Answer 3 quick questions to discover all central & state subsidies, scholarships, and cash assistance tailored to you.
          </p>
        </div>

        {/* Wizard Card Container */}
        <div className="bg-white rounded-3xl border border-stoneWarm-200 shadow-card overflow-hidden">
          
          {/* Top Progress Bar */}
          {step < 4 && (
            <div className="bg-stoneWarm-50 border-b border-stoneWarm-200 px-6 py-4 flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <span className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold ${
                  step === 1 ? 'bg-brand-600 text-white' : 'bg-brand-100 text-brand-700'
                }`}>
                  1
                </span>
                <span className="text-xs font-semibold text-stoneWarm-800">Demographics</span>
              </div>
              <div className="h-0.5 w-12 bg-stoneWarm-200 hidden sm:block"></div>
              <div className="flex items-center space-x-2">
                <span className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold ${
                  step === 2 ? 'bg-brand-600 text-white' : step > 2 ? 'bg-brand-100 text-brand-700' : 'bg-stoneWarm-200 text-stoneWarm-500'
                }`}>
                  2
                </span>
                <span className="text-xs font-semibold text-stoneWarm-800">Occupation & State</span>
              </div>
              <div className="h-0.5 w-12 bg-stoneWarm-200 hidden sm:block"></div>
              <div className="flex items-center space-x-2">
                <span className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold ${
                  step === 3 ? 'bg-brand-600 text-white' : 'bg-stoneWarm-200 text-stoneWarm-500'
                }`}>
                  3
                </span>
                <span className="text-xs font-semibold text-stoneWarm-800">Family Income</span>
              </div>
            </div>
          )}

          {/* Form Step 1: Demographics */}
          {step === 1 && (
            <div className="p-6 sm:p-8 space-y-6">
              <div className="border-b border-stoneWarm-100 pb-3">
                <h3 className="text-base font-bold text-stoneWarm-900">Step 1: Your Demographic Information</h3>
                <p className="text-xs text-stoneWarm-500">Helps determine age-bracket, gender-specific, and category quotas.</p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                <div>
                  <label className="block text-xs font-bold text-stoneWarm-800 mb-2">
                    Applicant Age: <span className="text-brand-600 text-sm font-extrabold">{calcData.age} Years</span>
                  </label>
                  <input
                    type="range"
                    min="5"
                    max="85"
                    value={calcData.age}
                    onChange={(e) => setCalcData({ ...calcData, age: Number(e.target.value) })}
                    className="w-full h-2 bg-stoneWarm-200 rounded-lg appearance-none cursor-pointer accent-brand-600"
                  />
                  <div className="flex justify-between text-[11px] text-stoneWarm-400 mt-1">
                    <span>5 yrs (Child)</span>
                    <span>18-60 (Adult)</span>
                    <span>60+ (Senior)</span>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-stoneWarm-800 mb-2">Gender</label>
                  <div className="grid grid-cols-3 gap-2">
                    {['Male', 'Female', 'Other'].map((g) => (
                      <button
                        key={g}
                        type="button"
                        onClick={() => setCalcData({ ...calcData, gender: g })}
                        className={`py-2 px-3 rounded-xl text-xs font-semibold border transition-all ${
                          calcData.gender === g
                            ? 'bg-brand-50 border-brand-500 text-brand-800 shadow-sm'
                            : 'bg-white border-stoneWarm-200 text-stoneWarm-700 hover:bg-stoneWarm-50'
                        }`}
                      >
                        {g}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="sm:col-span-2">
                  <label className="block text-xs font-bold text-stoneWarm-800 mb-2">Social Category</label>
                  <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
                    {[
                      { id: 'General', name: 'General' },
                      { id: 'OBC', name: 'OBC' },
                      { id: 'SC', name: 'SC' },
                      { id: 'ST', name: 'ST' },
                      { id: 'EWS', name: 'EWS' },
                    ].map((c) => (
                      <button
                        key={c.id}
                        type="button"
                        onClick={() => setCalcData({ ...calcData, category: c.id })}
                        className={`py-2.5 px-3 rounded-xl text-xs font-semibold border transition-all ${
                          calcData.category === c.id
                            ? 'bg-brand-600 border-brand-600 text-white shadow-sm'
                            : 'bg-stoneWarm-50 border-stoneWarm-200 text-stoneWarm-800 hover:bg-white'
                        }`}
                      >
                        {c.name}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              <div className="pt-4 flex justify-end">
                <button
                  type="button"
                  onClick={() => setStep(2)}
                  className="px-6 py-3 rounded-xl bg-brand-600 hover:bg-brand-700 text-white font-semibold text-xs flex items-center space-x-1.5 shadow-subtle"
                >
                  <span>Next: State & Occupation</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          )}

          {/* Form Step 2: Location & Occupation */}
          {step === 2 && (
            <div className="p-6 sm:p-8 space-y-6">
              <div className="border-b border-stoneWarm-100 pb-3">
                <h3 className="text-base font-bold text-stoneWarm-900">Step 2: Domicile State & Occupation</h3>
                <p className="text-xs text-stoneWarm-500">Helps include state-specific welfare initiatives alongside national schemes.</p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                <div>
                  <label className="block text-xs font-bold text-stoneWarm-800 mb-2">State of Domicile</label>
                  <select
                    value={calcData.state}
                    onChange={(e) => setCalcData({ ...calcData, state: e.target.value })}
                    className="w-full px-3 py-2.5 rounded-xl bg-stoneWarm-50 border border-stoneWarm-300 text-stoneWarm-900 text-xs font-medium focus:ring-1 focus:ring-brand-500"
                  >
                    {[
                      'Madhya Pradesh',
                      'Karnataka',
                      'Maharashtra',
                      'Uttar Pradesh',
                      'Rajasthan',
                      'Tamil Nadu',
                      'Bihar',
                      'Gujarat',
                      'West Bengal',
                      'Delhi NCR'
                    ].map((st) => (
                      <option key={st} value={st}>{st}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-stoneWarm-800 mb-2">Primary Occupation</label>
                  <select
                    value={calcData.occupation}
                    onChange={(e) => setCalcData({ ...calcData, occupation: e.target.value })}
                    className="w-full px-3 py-2.5 rounded-xl bg-stoneWarm-50 border border-stoneWarm-300 text-stoneWarm-900 text-xs font-medium focus:ring-1 focus:ring-brand-500"
                  >
                    <option value="Farmer">Farmer / Agriculture</option>
                    <option value="Student">Student (School / College)</option>
                    <option value="Artisan">Artisan / Traditional Craftsman</option>
                    <option value="Self Employed">Small Business / Self Employed</option>
                    <option value="Homemaker">Homemaker / Woman Head of Family</option>
                    <option value="Worker">Daily Wage / Construction Laborer</option>
                    <option value="Senior Citizen">Retired / Senior Citizen</option>
                  </select>
                </div>

                <div className="sm:col-span-2">
                  <label className="flex items-center space-x-2 bg-stoneWarm-50 p-3 rounded-xl border border-stoneWarm-200 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={calcData.hasLand}
                      onChange={(e) => setCalcData({ ...calcData, hasLand: e.target.checked })}
                      className="h-4 w-4 text-brand-600 rounded border-stoneWarm-300 focus:ring-brand-500"
                    />
                    <span className="text-xs font-medium text-stoneWarm-800">
                      I or my family own agricultural cultivable land (Qualifies for PM-KISAN, KCC)
                    </span>
                  </label>
                </div>
              </div>

              <div className="pt-4 flex justify-between">
                <button
                  type="button"
                  onClick={() => setStep(1)}
                  className="px-4 py-2.5 rounded-xl text-xs font-semibold text-stoneWarm-700 hover:bg-stoneWarm-100 flex items-center space-x-1"
                >
                  <ArrowLeft className="w-3.5 h-3.5" />
                  <span>Back</span>
                </button>
                <button
                  type="button"
                  onClick={() => setStep(3)}
                  className="px-6 py-3 rounded-xl bg-brand-600 hover:bg-brand-700 text-white font-semibold text-xs flex items-center space-x-1.5 shadow-subtle"
                >
                  <span>Next: Family Income</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          )}

          {/* Form Step 3: Annual Income */}
          {step === 3 && (
            <div className="p-6 sm:p-8 space-y-6">
              <div className="border-b border-stoneWarm-100 pb-3">
                <h3 className="text-base font-bold text-stoneWarm-900">Step 3: Annual Household Income</h3>
                <p className="text-xs text-stoneWarm-500">Most welfare subsidies and cash transfers have defined income thresholds.</p>
              </div>

              <div className="space-y-6">
                <div>
                  <div className="flex justify-between items-center mb-2">
                    <label className="text-xs font-bold text-stoneWarm-800">Total Family Annual Income:</label>
                    <span className="text-brand-700 text-base font-extrabold bg-brand-50 px-3 py-1 rounded-lg border border-brand-200">
                      ₹ {(calcData.annualIncome).toLocaleString('en-IN')} / year
                    </span>
                  </div>
                  <input
                    type="range"
                    min="50000"
                    max="1500000"
                    step="25000"
                    value={calcData.annualIncome}
                    onChange={(e) => setCalcData({ ...calcData, annualIncome: Number(e.target.value) })}
                    className="w-full h-2 bg-stoneWarm-200 rounded-lg appearance-none cursor-pointer accent-brand-600"
                  />
                  <div className="flex justify-between text-[11px] text-stoneWarm-400 mt-1">
                    <span>₹50,000 (BPL)</span>
                    <span>₹2.5 Lakh (EWS limit)</span>
                    <span>₹8 Lakh+</span>
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-2">
                  {[
                    { label: 'Below ₹1 Lakh', val: 90000 },
                    { label: '₹2.5 Lakh (Middle)', val: 240000 },
                    { label: '₹5 Lakh+', val: 550000 },
                  ].map((preset, idx) => (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => setCalcData({ ...calcData, annualIncome: preset.val })}
                      className="py-2 px-3 rounded-xl text-xs font-semibold bg-stoneWarm-100 hover:bg-stoneWarm-200 text-stoneWarm-800 text-center transition-colors"
                    >
                      {preset.label}
                    </button>
                  ))}
                </div>
              </div>

              <div className="pt-4 flex justify-between">
                <button
                  type="button"
                  onClick={() => setStep(2)}
                  className="px-4 py-2.5 rounded-xl text-xs font-semibold text-stoneWarm-700 hover:bg-stoneWarm-100 flex items-center space-x-1"
                >
                  <ArrowLeft className="w-3.5 h-3.5" />
                  <span>Back</span>
                </button>
                <button
                  type="button"
                  onClick={handleCalculate}
                  className="px-6 py-3 rounded-xl bg-brand-600 hover:bg-brand-700 text-white font-semibold text-xs flex items-center space-x-2 shadow-card"
                >
                  <Sparkles className="w-4 h-4 text-ochre-300" />
                  <span>Calculate Eligible Schemes</span>
                </button>
              </div>
            </div>
          )}

          {/* Step 4: Results Display */}
          {step === 4 && matchedResults && (
            <div className="p-6 sm:p-8 space-y-6">
              
              {/* Summary Banner */}
              <div className="bg-gradient-to-r from-brand-600 to-brand-700 rounded-2xl p-6 text-white shadow-card">
                <div className="flex items-center justify-between">
                  <div>
                    <span className="text-xs font-bold uppercase tracking-wider text-ochre-200 bg-black/20 px-2.5 py-1 rounded-md">
                      Eligibility Match Report
                    </span>
                    <h3 className="text-xl sm:text-2xl font-display font-extrabold mt-2">
                      You are eligible for {matchedResults.length} Government Schemes!
                    </h3>
                    <p className="text-xs sm:text-sm text-brand-100 mt-1">
                      Matched for: {calcData.age} yr old {calcData.gender} • {calcData.category} • {calcData.state}
                    </p>
                  </div>

                  <button
                    onClick={handleReset}
                    className="px-3 py-1.5 rounded-xl bg-white/20 hover:bg-white/30 text-white text-xs font-semibold flex items-center space-x-1 transition-colors"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                    <span>Recalculate</span>
                  </button>
                </div>
              </div>

              {/* Matched Scheme Cards */}
              <div className="space-y-3">
                <h4 className="text-xs font-bold uppercase tracking-wider text-stoneWarm-600">
                  Recommended Schemes for Instant Application:
                </h4>

                {matchedResults.map((scheme) => (
                  <div
                    key={scheme.id}
                    className="p-4 rounded-xl bg-stoneWarm-50 border border-stoneWarm-200 hover:border-brand-300 transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-4"
                  >
                    <div>
                      <div className="flex items-center space-x-2">
                        <span className="text-[10px] font-bold uppercase px-2 py-0.5 rounded bg-brand-100 text-brand-800">
                          {scheme.level} • {scheme.category}
                        </span>
                        <span className="text-xs text-stoneWarm-500 font-mono">{scheme.code}</span>
                      </div>
                      <h4 className="text-sm font-bold text-stoneWarm-900 mt-1">{scheme.title}</h4>
                      <p className="text-xs text-stoneWarm-600 mt-0.5">{scheme.shortDescription}</p>
                      <p className="text-xs font-bold text-brand-700 mt-1">
                        Direct Entitlement: {scheme.benefit}
                      </p>
                    </div>

                    <button
                      onClick={() => onApplyScheme(scheme)}
                      className="px-4 py-2.5 rounded-xl bg-brand-600 hover:bg-brand-700 text-white text-xs font-semibold whitespace-nowrap shadow-subtle flex items-center justify-center space-x-1"
                    >
                      <span>Apply Now</span>
                      <ChevronRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
              </div>

            </div>
          )}

        </div>

      </div>
    </section>
  );
};
