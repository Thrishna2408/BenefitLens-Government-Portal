import React, { useState } from 'react';
import { 
  User, 
  ShieldCheck, 
  FileText, 
  CheckCircle2, 
  Clock, 
  AlertCircle, 
  UploadCloud, 
  Building, 
  Banknote, 
  Sparkles, 
  ArrowRight, 
  Edit3, 
  Save, 
  ExternalLink,
  Lock,
  PlusCircle,
  Eye,
  Download
} from 'lucide-react';
import { SCHEMES_DATA } from '../data/mockData';

export const ProfileView = ({ 
  user, 
  setUser, 
  applications, 
  onTrackApp, 
  onApplyScheme 
}) => {
  const [activeTab, setActiveTab] = useState('applications'); // 'applications', 'locker', 'details', 'matches'
  const [isEditing, setIsEditing] = useState(false);
  const [docUploadModal, setDocUploadModal] = useState(false);
  const [newDocName, setNewDocName] = useState('');
  const [newDocType, setNewDocType] = useState('Income Proof');

  const [editFormData, setEditFormData] = useState({
    name: user?.name || 'Rajesh Kumar Verma',
    phone: user?.phone || '+91 98765 43210',
    email: user?.email || 'rajesh.verma@example.in',
    occupation: user?.occupation || 'Farmer / Agriculture',
    annualIncome: user?.annualIncome || '₹ 2,40,000',
    state: user?.state || 'Madhya Pradesh',
    district: user?.district || 'Indore',
    category: user?.category || 'OBC',
    bankName: user?.bankName || 'State Bank of India',
    accountNumber: user?.accountNumber || '••••••••4102',
    ifscCode: user?.ifscCode || 'SBIN0001842'
  });

  const handleSaveProfile = (e) => {
    e.preventDefault();
    setUser(prev => ({
      ...prev,
      ...editFormData
    }));
    setIsEditing(false);
    alert('Citizen Profile updated successfully with DigiLocker sync!');
  };

  const handleAddDocument = (e) => {
    e.preventDefault();
    if (!newDocName) return;

    const newDoc = {
      id: `doc-${Date.now()}`,
      name: newDocName,
      type: newDocType,
      status: 'Verified',
      date: new Date().toISOString().split('T')[0],
      size: '1.4 MB',
      verifiedBy: 'State e-Pramaan Gateway'
    };

    setUser(prev => ({
      ...prev,
      documentsLocker: [...(prev.documentsLocker || []), newDoc]
    }));

    setDocUploadModal(false);
    setNewDocName('');
    alert('Document added and verified in Digital Locker!');
  };

  // Matched schemes calculation
  const matchedSchemes = SCHEMES_DATA.filter(s => {
    return s.state === 'All India' || s.state === (user?.state || 'Madhya Pradesh');
  });

  const getStatusBadge = (status) => {
    switch (status) {
      case 'Approved':
      case 'Disbursed':
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-bold bg-brand-100 text-brand-800 border border-brand-200">
            <CheckCircle2 className="w-3 h-3 mr-1 text-brand-600" />
            {status}
          </span>
        );
      case 'Under Review':
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-bold bg-ochre-100 text-ochre-800 border border-ochre-200">
            <Clock className="w-3 h-3 mr-1 text-ochre-600" />
            Under Verification
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-bold bg-stoneWarm-200 text-stoneWarm-800">
            {status}
          </span>
        );
    }
  };

  return (
    <div className="py-10 bg-stoneWarm-50 min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Profile Master Card */}
        <div className="bg-white rounded-3xl border border-stoneWarm-200 shadow-card p-6 sm:p-8 mb-8">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
            
            {/* User Meta */}
            <div className="flex items-center space-x-4">
              <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl bg-gradient-to-tr from-brand-600 to-brand-500 text-white font-bold font-display text-2xl sm:text-3xl flex items-center justify-center shadow-card flex-shrink-0">
                {user?.avatarInitials || 'RV'}
              </div>

              <div>
                <div className="flex items-center space-x-2">
                  <h1 className="text-xl sm:text-2xl font-bold font-display text-stoneWarm-900">
                    {user?.name || 'Rajesh Kumar Verma'}
                  </h1>
                  <span className="inline-flex items-center space-x-1 px-2.5 py-0.5 rounded-full bg-brand-50 text-brand-700 border border-brand-200 text-xs font-bold">
                    <ShieldCheck className="w-3.5 h-3.5" />
                    <span>e-KYC Verified</span>
                  </span>
                </div>

                <div className="flex flex-wrap items-center gap-y-1 gap-x-4 text-xs text-stoneWarm-500 mt-1">
                  <span>Aadhaar: <strong className="text-stoneWarm-800 font-mono">{user?.aadhaarNumber || 'XXXX-XXXX-4819'}</strong></span>
                  <span>•</span>
                  <span>{user?.district || 'Indore'}, {user?.state || 'Madhya Pradesh'}</span>
                  <span>•</span>
                  <span>Category: <strong className="text-stoneWarm-800">{user?.category || 'OBC'}</strong></span>
                </div>
              </div>
            </div>

            {/* Benefit Summary Badge */}
            <div className="bg-gradient-to-r from-brand-50 via-ochre-50 to-stoneWarm-100 p-4 rounded-2xl border border-brand-200/80 flex items-center space-x-4">
              <div className="w-12 h-12 rounded-xl bg-brand-600 text-white flex items-center justify-center">
                <Banknote className="w-6 h-6 text-ochre-200" />
              </div>
              <div>
                <span className="text-[11px] font-bold uppercase tracking-wider text-brand-800 block">
                  Total Welfare Benefits Linked
                </span>
                <span className="text-xl font-bold font-display text-stoneWarm-900">
                  ₹ 84,000 / year
                </span>
                <span className="text-[11px] text-stoneWarm-500 block">
                  Direct to SBI A/c ending in 4102
                </span>
              </div>
            </div>

          </div>

          {/* Quick Metrics Bar */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-6 pt-6 border-t border-stoneWarm-100">
            <div className="bg-stoneWarm-50 p-3 rounded-xl border border-stoneWarm-200">
              <span className="text-xs text-stoneWarm-500 block">Active Applications</span>
              <span className="text-base font-bold text-stoneWarm-900">{applications.length} Schemes</span>
            </div>
            <div className="bg-stoneWarm-50 p-3 rounded-xl border border-stoneWarm-200">
              <span className="text-xs text-stoneWarm-500 block">Verified Digi-Docs</span>
              <span className="text-base font-bold text-stoneWarm-900">{user?.documentsLocker?.length || 5} Documents</span>
            </div>
            <div className="bg-stoneWarm-50 p-3 rounded-xl border border-stoneWarm-200">
              <span className="text-xs text-stoneWarm-500 block">Matched Schemes</span>
              <span className="text-base font-bold text-brand-700">{matchedSchemes.length} Available</span>
            </div>
            <div className="bg-stoneWarm-50 p-3 rounded-xl border border-stoneWarm-200">
              <span className="text-xs text-stoneWarm-500 block">NPCI DBT Status</span>
              <span className="text-base font-bold text-brand-700">Active & Seeded</span>
            </div>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex border-b border-stoneWarm-200 mb-6 overflow-x-auto scrollbar-none">
          {[
            { id: 'applications', label: 'My Applied Schemes', count: applications.length },
            { id: 'locker', label: 'Digital Document Locker', count: user?.documentsLocker?.length || 5 },
            { id: 'matches', label: 'Matched Schemes for You', count: matchedSchemes.length },
            { id: 'details', label: 'Demographic & Bank Details' }
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`py-3 px-5 text-xs sm:text-sm font-semibold border-b-2 whitespace-nowrap transition-all flex items-center space-x-2 ${
                activeTab === tab.id
                  ? 'border-brand-600 text-brand-700 bg-white rounded-t-xl'
                  : 'border-transparent text-stoneWarm-500 hover:text-stoneWarm-900'
              }`}
            >
              <span>{tab.label}</span>
              {tab.count !== undefined && (
                <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                  activeTab === tab.id ? 'bg-brand-100 text-brand-800' : 'bg-stoneWarm-200 text-stoneWarm-700'
                }`}>
                  {tab.count}
                </span>
              )}
            </button>
          ))}
        </div>

        {/* Tab 1: My Applied Schemes */}
        {activeTab === 'applications' && (
          <div className="space-y-4">
            {applications.map((app) => (
              <div
                key={app.id}
                className="bg-white rounded-2xl border border-stoneWarm-200 shadow-subtle p-6 hover:border-brand-300 transition-all"
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-stoneWarm-100">
                  <div>
                    <div className="flex items-center space-x-2">
                      <span className="text-xs font-mono font-bold text-stoneWarm-600 bg-stoneWarm-100 px-2 py-0.5 rounded">
                        Ref: {app.id}
                      </span>
                      {getStatusBadge(app.status)}
                    </div>
                    <h3 className="text-base sm:text-lg font-bold text-stoneWarm-900 mt-1">
                      {app.schemeTitle}
                    </h3>
                    <p className="text-xs text-stoneWarm-500">
                      Applied on {app.appliedDate} • Benefit: <strong className="text-stoneWarm-800">{app.disbursedAmount}</strong>
                    </p>
                  </div>

                  <div className="flex items-center space-x-2">
                    <button
                      onClick={() => onTrackApp(app.id)}
                      className="px-4 py-2 rounded-xl bg-brand-600 hover:bg-brand-700 text-white text-xs font-semibold shadow-subtle flex items-center space-x-1"
                    >
                      <span>Track Live DBT Status</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                {/* Micro Progress Bar */}
                <div className="mt-4">
                  <div className="flex justify-between text-xs text-stoneWarm-500 mb-1.5 font-medium">
                    <span>1. Applied</span>
                    <span>2. Desk Review</span>
                    <span>3. Sanction Issued</span>
                    <span>4. Direct Bank Credit</span>
                  </div>
                  <div className="w-full h-2 bg-stoneWarm-100 rounded-full overflow-hidden flex">
                    <div
                      className="bg-brand-600 h-full rounded-full transition-all duration-500"
                      style={{ width: `${(app.currentStage / 4) * 100}%` }}
                    ></div>
                  </div>
                </div>

                {/* Remarks preview */}
                {app.officerRemarks && (
                  <div className="mt-4 p-3 rounded-xl bg-stoneWarm-50 border border-stoneWarm-200 text-xs text-stoneWarm-700 flex items-start space-x-2">
                    <ShieldCheck className="w-4 h-4 text-brand-600 flex-shrink-0 mt-0.5" />
                    <span><strong>Desk Note:</strong> {app.officerRemarks}</span>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}

        {/* Tab 2: Digital Document Locker */}
        {activeTab === 'locker' && (
          <div className="space-y-6">
            <div className="bg-white p-6 rounded-2xl border border-stoneWarm-200 shadow-subtle flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h3 className="text-base font-bold text-stoneWarm-900">National DigiLocker Synchronization</h3>
                <p className="text-xs text-stoneWarm-500 mt-0.5">
                  All documents are cryptographically verified by issuing state and central authorities.
                </p>
              </div>

              <button
                onClick={() => setDocUploadModal(true)}
                className="px-4 py-2.5 rounded-xl bg-brand-600 hover:bg-brand-700 text-white text-xs font-semibold shadow-subtle flex items-center space-x-1.5 whitespace-nowrap"
              >
                <PlusCircle className="w-4 h-4" />
                <span>Add / Upload Document</span>
              </button>
            </div>

            {/* Documents Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {(user?.documentsLocker || []).map((doc) => (
                <div
                  key={doc.id}
                  className="bg-white p-5 rounded-2xl border border-stoneWarm-200 shadow-subtle flex flex-col justify-between"
                >
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-[10px] font-bold uppercase tracking-wider bg-stoneWarm-100 text-stoneWarm-700 px-2 py-0.5 rounded">
                        {doc.type}
                      </span>
                      <span className="text-xs font-bold text-brand-700 flex items-center">
                        <CheckCircle2 className="w-3.5 h-3.5 mr-1" />
                        {doc.status}
                      </span>
                    </div>

                    <h4 className="text-sm font-bold text-stoneWarm-900 mt-1 line-clamp-1">{doc.name}</h4>
                    <p className="text-xs text-stoneWarm-500 mt-1">
                      Verified by: <strong className="text-stoneWarm-700">{doc.verifiedBy}</strong>
                    </p>
                    <p className="text-[11px] text-stoneWarm-400 mt-0.5">
                      Updated: {doc.date} • {doc.size}
                    </p>
                  </div>

                  <div className="mt-4 pt-3 border-t border-stoneWarm-100 flex items-center justify-between">
                    <button
                      onClick={() => alert(`Viewing document ${doc.name}`)}
                      className="text-xs font-semibold text-brand-700 hover:text-brand-800 flex items-center space-x-1"
                    >
                      <Eye className="w-3.5 h-3.5" />
                      <span>Preview Doc</span>
                    </button>
                    <button
                      onClick={() => alert(`Downloading certificate for ${doc.name}`)}
                      className="text-xs font-semibold text-stoneWarm-500 hover:text-stoneWarm-800 flex items-center space-x-1"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>Download</span>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Tab 3: Matched Schemes */}
        {activeTab === 'matches' && (
          <div className="space-y-4">
            <div className="bg-brand-50 border border-brand-200 rounded-2xl p-4 text-xs text-brand-900 flex items-center justify-between">
              <span>
                Based on your profile attributes (<strong>{user?.category}</strong>, <strong>{user?.occupation}</strong>, <strong>{user?.state}</strong>), these schemes offer guaranteed eligibility.
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {matchedSchemes.map((scheme) => (
                <div
                  key={scheme.id}
                  className="bg-white p-5 rounded-2xl border border-stoneWarm-200 shadow-subtle flex flex-col justify-between"
                >
                  <div>
                    <div className="flex justify-between items-center mb-1">
                      <span className="text-[11px] font-bold text-brand-700 bg-brand-50 px-2 py-0.5 rounded">
                        {scheme.category}
                      </span>
                      <span className="text-xs font-bold text-stoneWarm-900">{scheme.benefit}</span>
                    </div>
                    <h4 className="text-sm font-bold text-stoneWarm-900 mt-1">{scheme.title}</h4>
                    <p className="text-xs text-stoneWarm-600 mt-1 line-clamp-2">{scheme.shortDescription}</p>
                  </div>

                  <div className="mt-4 pt-3 border-t border-stoneWarm-100 flex justify-end">
                    <button
                      onClick={() => onApplyScheme(scheme)}
                      className="px-4 py-2 rounded-xl bg-brand-600 hover:bg-brand-700 text-white text-xs font-semibold shadow-subtle flex items-center space-x-1"
                    >
                      <span>1-Click DigiApply</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Tab 4: Demographic & Bank Details */}
        {activeTab === 'details' && (
          <div className="bg-white rounded-3xl border border-stoneWarm-200 shadow-card p-6 sm:p-8">
            <div className="flex justify-between items-center mb-6 pb-4 border-b border-stoneWarm-200">
              <div>
                <h3 className="text-base font-bold text-stoneWarm-900">Demographic & Direct Bank Transfer Settings</h3>
                <p className="text-xs text-stoneWarm-500">Ensure bank details are mapped with NPCI for receiving welfare funds.</p>
              </div>

              {!isEditing ? (
                <button
                  onClick={() => setIsEditing(true)}
                  className="px-4 py-2 rounded-xl border border-stoneWarm-300 text-stoneWarm-800 hover:bg-stoneWarm-100 text-xs font-semibold flex items-center space-x-1.5"
                >
                  <Edit3 className="w-3.5 h-3.5" />
                  <span>Edit Profile</span>
                </button>
              ) : null}
            </div>

            <form onSubmit={handleSaveProfile} className="space-y-6">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-stoneWarm-700 mb-1">Full Legal Name</label>
                  <input
                    type="text"
                    disabled={!isEditing}
                    value={editFormData.name}
                    onChange={(e) => setEditFormData({ ...editFormData, name: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-stoneWarm-50 border border-stoneWarm-300 text-stoneWarm-900 text-xs focus:ring-1 focus:ring-brand-500 disabled:bg-stoneWarm-100 disabled:text-stoneWarm-600"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-stoneWarm-700 mb-1">Mobile (Linked to Aadhaar)</label>
                  <input
                    type="text"
                    disabled={!isEditing}
                    value={editFormData.phone}
                    onChange={(e) => setEditFormData({ ...editFormData, phone: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-stoneWarm-50 border border-stoneWarm-300 text-stoneWarm-900 text-xs focus:ring-1 focus:ring-brand-500 disabled:bg-stoneWarm-100 disabled:text-stoneWarm-600"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-stoneWarm-700 mb-1">Primary Occupation</label>
                  <input
                    type="text"
                    disabled={!isEditing}
                    value={editFormData.occupation}
                    onChange={(e) => setEditFormData({ ...editFormData, occupation: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-stoneWarm-50 border border-stoneWarm-300 text-stoneWarm-900 text-xs focus:ring-1 focus:ring-brand-500 disabled:bg-stoneWarm-100 disabled:text-stoneWarm-600"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-stoneWarm-700 mb-1">Annual Household Income</label>
                  <input
                    type="text"
                    disabled={!isEditing}
                    value={editFormData.annualIncome}
                    onChange={(e) => setEditFormData({ ...editFormData, annualIncome: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-stoneWarm-50 border border-stoneWarm-300 text-stoneWarm-900 text-xs focus:ring-1 focus:ring-brand-500 disabled:bg-stoneWarm-100 disabled:text-stoneWarm-600"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-stoneWarm-700 mb-1">Bank Name</label>
                  <input
                    type="text"
                    disabled={!isEditing}
                    value={editFormData.bankName}
                    onChange={(e) => setEditFormData({ ...editFormData, bankName: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-stoneWarm-50 border border-stoneWarm-300 text-stoneWarm-900 text-xs focus:ring-1 focus:ring-brand-500 disabled:bg-stoneWarm-100 disabled:text-stoneWarm-600"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-stoneWarm-700 mb-1">Account Number (Masked)</label>
                  <input
                    type="text"
                    disabled={!isEditing}
                    value={editFormData.accountNumber}
                    onChange={(e) => setEditFormData({ ...editFormData, accountNumber: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-stoneWarm-50 border border-stoneWarm-300 text-stoneWarm-900 text-xs font-mono focus:ring-1 focus:ring-brand-500 disabled:bg-stoneWarm-100 disabled:text-stoneWarm-600"
                  />
                </div>
              </div>

              {isEditing && (
                <div className="pt-4 flex justify-end space-x-2">
                  <button
                    type="button"
                    onClick={() => setIsEditing(false)}
                    className="px-4 py-2 rounded-xl text-xs font-semibold text-stoneWarm-700 hover:bg-stoneWarm-100"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-6 py-2.5 rounded-xl bg-brand-600 hover:bg-brand-700 text-white font-semibold text-xs flex items-center space-x-1.5 shadow-subtle"
                  >
                    <Save className="w-3.5 h-3.5" />
                    <span>Save Changes</span>
                  </button>
                </div>
              )}
            </form>
          </div>
        )}

      </div>

      {/* Add Document Modal */}
      {docUploadModal && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-black/50 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl border border-stoneWarm-200 shadow-modal max-w-md w-full p-6">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-base font-bold text-stoneWarm-900">Upload to DigiLocker</h3>
              <button onClick={() => setDocUploadModal(false)} className="text-stoneWarm-400 hover:text-stoneWarm-700">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleAddDocument} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-stoneWarm-700 mb-1">Document Title</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Disability Certificate / Marksheet"
                  value={newDocName}
                  onChange={(e) => setNewDocName(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-stoneWarm-50 border border-stoneWarm-300 text-stoneWarm-900 text-xs focus:ring-1 focus:ring-brand-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-stoneWarm-700 mb-1">Document Category</label>
                <select
                  value={newDocType}
                  onChange={(e) => setNewDocType(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-stoneWarm-50 border border-stoneWarm-300 text-stoneWarm-900 text-xs focus:ring-1 focus:ring-brand-500"
                >
                  <option value="Income Proof">Income Proof</option>
                  <option value="Identity & Domicile">Identity & Domicile</option>
                  <option value="Land & Property">Land & Property</option>
                  <option value="Education Certificate">Education Certificate</option>
                  <option value="Banking & Cheque">Banking & Cheque</option>
                </select>
              </div>

              <div className="p-6 border-2 border-dashed border-stoneWarm-300 rounded-2xl text-center bg-stoneWarm-50">
                <UploadCloud className="w-8 h-8 text-brand-600 mx-auto mb-2" />
                <p className="text-xs font-semibold text-stoneWarm-800">Click to browse or drag PDF / JPG</p>
                <p className="text-[10px] text-stoneWarm-400 mt-1">Maximum file size: 5 MB</p>
              </div>

              <div className="flex justify-end space-x-2 pt-2">
                <button
                  type="button"
                  onClick={() => setDocUploadModal(false)}
                  className="px-4 py-2 rounded-xl text-xs font-semibold text-stoneWarm-700 hover:bg-stoneWarm-100"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 rounded-xl bg-brand-600 hover:bg-brand-700 text-white text-xs font-semibold shadow-subtle"
                >
                  Verify & Store in Locker
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
