import React, { useState } from 'react';
import { 
  X, 
  User, 
  Shield, 
  Lock, 
  Phone, 
  Mail, 
  CheckCircle2, 
  Eye, 
  EyeOff, 
  Sparkles, 
  Building2, 
  ArrowRight,
  Fingerprint,
  FileCheck2
} from 'lucide-react';
import { MOCK_USER_PROFILE } from '../data/mockData';

export const AuthModal = ({ isOpen, onClose, initialMode = 'login', onLoginSuccess }) => {
  const [mode, setMode] = useState(initialMode); // 'login' or 'register'
  const [role, setRole] = useState('citizen'); // 'citizen', 'officer', 'admin'
  const [authMethod, setAuthMethod] = useState('otp'); // 'otp' or 'password'
  
  const [phone, setPhone] = useState('9876543210');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [otpSent, setOtpSent] = useState(false);
  const [otpValue, setOtpValue] = useState('');
  const [registerName, setRegisterName] = useState('');
  const [registerAadhaar, setRegisterAadhaar] = useState('');

  if (!isOpen) return null;

  const handleSendOtp = (e) => {
    e.preventDefault();
    if (!phone || phone.length < 10) {
      alert('Please enter a valid 10-digit mobile number');
      return;
    }
    setOtpSent(true);
    setOtpValue('4829'); // Auto simulated OTP
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    
    let loggedUser = { ...MOCK_USER_PROFILE };

    if (role === 'admin') {
      loggedUser = {
        name: 'Dr. Rameshwar Singh (IAS)',
        email: 'admin.schemesetu@gov.in',
        phone: '+91 94120 00001',
        role: 'admin',
        avatarInitials: 'RS'
      };
    } else if (role === 'officer') {
      loggedUser = {
        name: 'Pooja Deshmukh (Verification Officer)',
        email: 'pooja.officer@mp.gov.in',
        phone: '+91 98230 11223',
        role: 'officer',
        avatarInitials: 'PD'
      };
    } else if (mode === 'register') {
      loggedUser = {
        ...MOCK_USER_PROFILE,
        name: registerName || 'New Citizen',
        phone: `+91 ${phone}`,
        aadhaarNumber: registerAadhaar ? `XXXX-XXXX-${registerAadhaar.slice(-4)}` : 'XXXX-XXXX-9912',
        role: 'citizen',
        avatarInitials: (registerName || 'NC').slice(0, 2).toUpperCase()
      };
    }

    onLoginSuccess(loggedUser);
    onClose();
  };

  const handleQuickDemoLogin = (selectedRole) => {
    let demoUser;
    if (selectedRole === 'admin') {
      demoUser = {
        name: 'Dr. Rameshwar Singh (IAS)',
        email: 'admin.schemesetu@gov.in',
        phone: '+91 94120 00001',
        role: 'admin',
        avatarInitials: 'RS'
      };
    } else if (selectedRole === 'officer') {
      demoUser = {
        name: 'Pooja Deshmukh (Verification Officer)',
        email: 'pooja.officer@mp.gov.in',
        phone: '+91 98230 11223',
        role: 'officer',
        avatarInitials: 'PD'
      };
    } else {
      demoUser = { ...MOCK_USER_PROFILE };
    }

    onLoginSuccess(demoUser);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-stoneWarm-950/60 backdrop-blur-sm flex items-center justify-center p-4 animate-fadeIn">
      <div className="bg-white rounded-3xl border border-stoneWarm-200 shadow-modal max-w-md w-full overflow-hidden">
        
        {/* Top Header */}
        <div className="px-6 pt-6 pb-4 bg-stoneWarm-50/80 border-b border-stoneWarm-200 flex items-center justify-between">
          <div className="flex items-center space-x-2.5">
            <div className="w-9 h-9 rounded-xl bg-brand-600 text-white flex items-center justify-center font-bold text-lg">
              स
            </div>
            <div>
              <h3 className="text-base font-bold text-stoneWarm-900 font-display">
                {mode === 'login' ? 'Sign In to SchemeSetu' : 'Citizen Registration'}
              </h3>
              <p className="text-[11px] text-stoneWarm-500">
                Single Sign-On for all Welfare Schemes
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-full text-stoneWarm-400 hover:text-stoneWarm-700 hover:bg-stoneWarm-200 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Mode Toggle (Sign In / Register) */}
        <div className="grid grid-cols-2 p-1.5 bg-stoneWarm-100 mx-6 mt-4 rounded-xl border border-stoneWarm-200 text-xs font-semibold">
          <button
            onClick={() => setMode('login')}
            className={`py-2 rounded-lg transition-all ${
              mode === 'login'
                ? 'bg-white text-stoneWarm-900 shadow-subtle'
                : 'text-stoneWarm-600 hover:text-stoneWarm-900'
            }`}
          >
            Sign In
          </button>
          <button
            onClick={() => setMode('register')}
            className={`py-2 rounded-lg transition-all ${
              mode === 'register'
                ? 'bg-white text-stoneWarm-900 shadow-subtle'
                : 'text-stoneWarm-600 hover:text-stoneWarm-900'
            }`}
          >
            Register (New Citizen)
          </button>
        </div>

        {/* Role Selector Pills */}
        <div className="px-6 mt-3">
          <label className="text-[11px] font-bold uppercase tracking-wider text-stoneWarm-500 block mb-1.5">
            Access Role:
          </label>
          <div className="grid grid-cols-3 gap-1.5">
            {[
              { id: 'citizen', label: 'Citizen' },
              { id: 'officer', label: 'Scheme Officer' },
              { id: 'admin', label: 'Central Admin' },
            ].map((r) => (
              <button
                key={r.id}
                type="button"
                onClick={() => setRole(r.id)}
                className={`py-1.5 px-2 rounded-lg text-xs font-medium border transition-all text-center ${
                  role === r.id
                    ? 'bg-brand-50 border-brand-500 text-brand-800 font-bold'
                    : 'bg-stoneWarm-50 border-stoneWarm-200 text-stoneWarm-600 hover:bg-stoneWarm-100'
                }`}
              >
                {r.label}
              </button>
            ))}
          </div>
        </div>

        {/* Form Body */}
        <div className="p-6">
          <form onSubmit={handleSubmit} className="space-y-3.5">
            
            {/* Registration Fields */}
            {mode === 'register' && (
              <>
                <div>
                  <label className="block text-xs font-semibold text-stoneWarm-700 mb-1">
                    Full Name (as on Aadhaar)
                  </label>
                  <div className="relative">
                    <User className="w-4 h-4 text-stoneWarm-400 absolute left-3 top-2.5" />
                    <input
                      type="text"
                      required
                      value={registerName}
                      onChange={(e) => setRegisterName(e.target.value)}
                      placeholder="e.g. Rajesh Kumar Verma"
                      className="w-full pl-9 pr-3 py-2 rounded-xl bg-stoneWarm-50 border border-stoneWarm-300 text-stoneWarm-900 text-xs focus:ring-1 focus:ring-brand-500"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-stoneWarm-700 mb-1">
                    12-Digit Aadhaar Number
                  </label>
                  <div className="relative">
                    <Fingerprint className="w-4 h-4 text-stoneWarm-400 absolute left-3 top-2.5" />
                    <input
                      type="text"
                      maxLength={12}
                      value={registerAadhaar}
                      onChange={(e) => setRegisterAadhaar(e.target.value)}
                      placeholder="XXXX XXXX XXXX"
                      className="w-full pl-9 pr-3 py-2 rounded-xl bg-stoneWarm-50 border border-stoneWarm-300 text-stoneWarm-900 text-xs font-mono focus:ring-1 focus:ring-brand-500"
                    />
                  </div>
                </div>
              </>
            )}

            {/* Mobile Number & OTP Method */}
            {authMethod === 'otp' ? (
              <div>
                <label className="block text-xs font-semibold text-stoneWarm-700 mb-1">
                  Registered Mobile Number
                </label>
                <div className="flex space-x-2">
                  <div className="relative flex-1">
                    <span className="text-xs text-stoneWarm-500 absolute left-3 top-2 font-medium">+91</span>
                    <input
                      type="tel"
                      maxLength={10}
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      placeholder="98765 43210"
                      className="w-full pl-10 pr-3 py-2 rounded-xl bg-stoneWarm-50 border border-stoneWarm-300 text-stoneWarm-900 text-xs focus:ring-1 focus:ring-brand-500"
                    />
                  </div>
                  {!otpSent ? (
                    <button
                      type="button"
                      onClick={handleSendOtp}
                      className="px-3 py-2 rounded-xl bg-stoneWarm-800 hover:bg-stoneWarm-900 text-stoneWarm-50 text-xs font-semibold whitespace-nowrap"
                    >
                      Get OTP
                    </button>
                  ) : null}
                </div>

                {otpSent && (
                  <div className="mt-3 p-3 bg-brand-50 border border-brand-200 rounded-xl space-y-2">
                    <div className="flex justify-between items-center text-xs">
                      <span className="text-brand-800 font-semibold">Enter 4-Digit OTP</span>
                      <span className="text-[10px] text-stoneWarm-500">Simulated code: <strong>4829</strong></span>
                    </div>
                    <input
                      type="text"
                      maxLength={4}
                      value={otpValue}
                      onChange={(e) => setOtpValue(e.target.value)}
                      placeholder="4829"
                      className="w-full text-center tracking-widest font-mono text-base font-bold py-1.5 rounded-lg bg-white border border-brand-300 text-stoneWarm-900 focus:outline-none"
                    />
                  </div>
                )}
              </div>
            ) : (
              <div>
                <label className="block text-xs font-semibold text-stoneWarm-700 mb-1">
                  Email Address / Gov ID
                </label>
                <div className="relative mb-2.5">
                  <Mail className="w-4 h-4 text-stoneWarm-400 absolute left-3 top-2.5" />
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="name@example.gov.in"
                    className="w-full pl-9 pr-3 py-2 rounded-xl bg-stoneWarm-50 border border-stoneWarm-300 text-stoneWarm-900 text-xs focus:ring-1 focus:ring-brand-500"
                  />
                </div>

                <label className="block text-xs font-semibold text-stoneWarm-700 mb-1">
                  Password
                </label>
                <div className="relative">
                  <Lock className="w-4 h-4 text-stoneWarm-400 absolute left-3 top-2.5" />
                  <input
                    type={showPassword ? 'text' : 'password'}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full pl-9 pr-9 py-2 rounded-xl bg-stoneWarm-50 border border-stoneWarm-300 text-stoneWarm-900 text-xs focus:ring-1 focus:ring-brand-500"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="text-stoneWarm-400 hover:text-stoneWarm-600 absolute right-3 top-2.5"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>
            )}

            {/* Auth Switcher */}
            <div className="flex justify-between items-center text-xs pt-1">
              <button
                type="button"
                onClick={() => setAuthMethod(authMethod === 'otp' ? 'password' : 'otp')}
                className="text-brand-700 hover:text-brand-800 font-semibold underline-offset-2 hover:underline"
              >
                {authMethod === 'otp' ? 'Sign in with Password instead' : 'Sign in with Mobile OTP'}
              </button>
            </div>

            {/* Main Submit Button */}
            <button
              type="submit"
              className="w-full py-3 rounded-xl bg-brand-600 hover:bg-brand-700 text-white font-semibold text-xs transition-all shadow-subtle flex items-center justify-center space-x-1.5"
            >
              <span>{mode === 'login' ? 'Authenticate & Enter' : 'Complete Citizen Registration'}</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </form>

          {/* Quick Demo Fill Buttons Section */}
          <div className="mt-5 pt-4 border-t border-stoneWarm-200">
            <p className="text-[11px] text-stoneWarm-500 font-semibold uppercase tracking-wider text-center mb-2.5">
              1-Click Demo Accounts (Instant Test)
            </p>
            <div className="grid grid-cols-3 gap-1.5">
              <button
                type="button"
                onClick={() => handleQuickDemoLogin('citizen')}
                className="p-2 rounded-lg bg-stoneWarm-100 hover:bg-brand-50 border border-stoneWarm-200 text-stoneWarm-800 hover:text-brand-800 text-[11px] font-semibold text-center transition-colors"
              >
                Citizen (Rajesh)
              </button>
              <button
                type="button"
                onClick={() => handleQuickDemoLogin('officer')}
                className="p-2 rounded-lg bg-stoneWarm-100 hover:bg-ochre-50 border border-stoneWarm-200 text-stoneWarm-800 hover:text-ochre-800 text-[11px] font-semibold text-center transition-colors"
              >
                Scheme Officer
              </button>
              <button
                type="button"
                onClick={() => handleQuickDemoLogin('admin')}
                className="p-2 rounded-lg bg-stoneWarm-100 hover:bg-stoneWarm-200 border border-stoneWarm-200 text-stoneWarm-800 text-[11px] font-semibold text-center transition-colors"
              >
                Central Admin
              </button>
            </div>
          </div>

        </div>

      </div>
    </div>
  );
};
