import React, { useState } from 'react';
import { 
  Building2, 
  Search, 
  User, 
  ShieldAlert, 
  Menu, 
  X, 
  ChevronDown, 
  Globe, 
  CheckCircle2, 
  FileText, 
  Sparkles,
  LayoutDashboard,
  LogOut,
  SlidersHorizontal
} from 'lucide-react';

export const Navbar = ({ 
  activeView, 
  setActiveView, 
  user, 
  onOpenAuth, 
  onLogout,
  onOpenGrievance,
  selectedLanguage,
  setSelectedLanguage
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [userDropdownOpen, setUserDropdownOpen] = useState(false);
  const [langDropdownOpen, setLangDropdownOpen] = useState(false);

  const languages = [
    { code: 'en', label: 'English' },
    { code: 'hi', label: 'हिन्दी (Hindi)' },
    { code: 'mr', label: 'मराठी (Marathi)' },
    { code: 'ta', label: 'தமிழ் (Tamil)' },
    { code: 'te', label: 'తెలుగు (Telugu)' },
  ];

  return (
    <header className="sticky top-0 z-40 bg-stoneWarm-50/95 backdrop-blur-md border-b border-stoneWarm-200/80 shadow-subtle transition-all">
      {/* Top micro-bar for Government / Public Trust */}
      <div className="bg-stoneWarm-900 text-stoneWarm-200 text-xs px-4 py-1.5 flex justify-between items-center">
        <div className="flex items-center space-x-2 max-w-7xl mx-auto w-full">
          <span className="inline-flex items-center text-ochre-400 font-medium">
            <Building2 className="w-3.5 h-3.5 mr-1" />
            Direct Citizen Welfare & DBT Portal — Government of India & States
          </span>
          <span className="hidden md:inline-block text-stoneWarm-500">•</span>
          <span className="hidden md:inline-block text-stoneWarm-400">Toll Free Citizen Helpline: 1800-11-7788</span>
          
          <div className="ml-auto flex items-center space-x-4">
            <button 
              onClick={onOpenGrievance} 
              className="text-stoneWarm-300 hover:text-ochre-300 transition-colors underline-offset-2 hover:underline"
            >
              Public Grievance Portal
            </button>
            <div className="relative">
              <button 
                onClick={() => setLangDropdownOpen(!langDropdownOpen)}
                className="flex items-center space-x-1 text-stoneWarm-300 hover:text-white px-2 py-0.5 rounded bg-stoneWarm-800 border border-stoneWarm-700 text-xs"
              >
                <Globe className="w-3 h-3 text-brand-400" />
                <span>{languages.find(l => l.code === selectedLanguage)?.label.split(' ')[0]}</span>
                <ChevronDown className="w-3 h-3 text-stoneWarm-400" />
              </button>

              {langDropdownOpen && (
                <div className="absolute right-0 mt-1 w-40 bg-stoneWarm-900 border border-stoneWarm-700 rounded-lg shadow-modal py-1 z-50">
                  {languages.map((lang) => (
                    <button
                      key={lang.code}
                      onClick={() => {
                        setSelectedLanguage(lang.code);
                        setLangDropdownOpen(false);
                      }}
                      className={`w-full text-left px-3 py-1.5 text-xs hover:bg-stoneWarm-800 transition-colors ${
                        selectedLanguage === lang.code ? 'text-brand-400 font-semibold bg-stoneWarm-800/60' : 'text-stoneWarm-300'
                      }`}
                    >
                      {lang.label}
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Main Navbar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          
          {/* Brand Emblem & Name */}
          <div 
            onClick={() => setActiveView('home')} 
            className="flex items-center space-x-3 cursor-pointer group select-none"
          >
            <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-brand-500 to-brand-700 text-stoneWarm-50 flex items-center justify-center shadow-card group-hover:scale-105 transition-transform duration-200">
              <span className="font-display font-bold text-2xl tracking-tighter">स</span>
            </div>
            <div>
              <div className="flex items-center space-x-1.5">
                <span className="font-display font-bold text-2xl tracking-tight text-stoneWarm-900 group-hover:text-brand-700 transition-colors">
                  Scheme<span className="text-brand-600">Setu</span>
                </span>
                <span className="bg-brand-100 text-brand-800 text-[10px] font-semibold uppercase tracking-wider px-2 py-0.5 rounded-full border border-brand-200">
                  Welfare
                </span>
              </div>
              <p className="text-[11px] text-stoneWarm-500 font-medium tracking-wide">
                Unified Citizen & Scheme Bridge
              </p>
            </div>
          </div>

          {/* Desktop Navigation Menu */}
          <nav className="hidden lg:flex items-center space-x-1">
            <button
              onClick={() => setActiveView('home')}
              className={`px-3.5 py-2 rounded-lg text-sm font-medium transition-all ${
                activeView === 'home'
                  ? 'bg-brand-50 text-brand-700 font-semibold border border-brand-200/60'
                  : 'text-stoneWarm-700 hover:text-stoneWarm-900 hover:bg-stoneWarm-100/70'
              }`}
            >
              Discover Schemes
            </button>

            <button
              onClick={() => setActiveView('calculator')}
              className={`px-3.5 py-2 rounded-lg text-sm font-medium transition-all flex items-center space-x-1.5 ${
                activeView === 'calculator'
                  ? 'bg-brand-50 text-brand-700 font-semibold border border-brand-200/60'
                  : 'text-stoneWarm-700 hover:text-stoneWarm-900 hover:bg-stoneWarm-100/70'
              }`}
            >
              <Sparkles className="w-4 h-4 text-ochre-500" />
              <span>Eligibility Checker</span>
            </button>

            <button
              onClick={() => setActiveView('tracker')}
              className={`px-3.5 py-2 rounded-lg text-sm font-medium transition-all flex items-center space-x-1.5 ${
                activeView === 'tracker'
                  ? 'bg-brand-50 text-brand-700 font-semibold border border-brand-200/60'
                  : 'text-stoneWarm-700 hover:text-stoneWarm-900 hover:bg-stoneWarm-100/70'
              }`}
            >
              <FileText className="w-4 h-4 text-stoneWarm-500" />
              <span>Track Application</span>
            </button>

            <button
              onClick={() => setActiveView('admin')}
              className={`px-3.5 py-2 rounded-lg text-sm font-medium transition-all flex items-center space-x-1.5 ${
                activeView === 'admin'
                  ? 'bg-stoneWarm-800 text-stoneWarm-50 font-semibold shadow-sm'
                  : 'text-stoneWarm-700 hover:text-stoneWarm-900 hover:bg-stoneWarm-100/70'
              }`}
            >
              <LayoutDashboard className="w-4 h-4 text-ochre-400" />
              <span>Admin Portal</span>
            </button>
          </nav>

          {/* Right Action & Auth Area */}
          <div className="hidden sm:flex items-center space-x-3">
            {user ? (
              <div className="relative">
                <button
                  onClick={() => setUserDropdownOpen(!userDropdownOpen)}
                  className="flex items-center space-x-2.5 p-1.5 pl-3 rounded-full bg-stoneWarm-100 border border-stoneWarm-200/90 hover:border-brand-300 transition-all text-left shadow-subtle"
                >
                  <div className="flex flex-col">
                    <span className="text-xs font-semibold text-stoneWarm-900 line-clamp-1">{user.name}</span>
                    <span className="text-[10px] text-brand-700 font-medium capitalize flex items-center">
                      <CheckCircle2 className="w-2.5 h-2.5 mr-0.5 text-ochre-600 inline" />
                      {user.role}
                    </span>
                  </div>
                  <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-brand-600 to-brand-500 text-white font-bold text-xs flex items-center justify-center shadow-sm">
                    {user.avatarInitials || user.name.charAt(0)}
                  </div>
                  <ChevronDown className="w-4 h-4 text-stoneWarm-400 pr-0.5" />
                </button>

                {userDropdownOpen && (
                  <div className="absolute right-0 mt-2 w-56 bg-white border border-stoneWarm-200 rounded-xl shadow-modal py-2 z-50">
                    <div className="px-4 py-2 border-b border-stoneWarm-100">
                      <p className="text-xs text-stoneWarm-500">Signed in as</p>
                      <p className="text-sm font-semibold text-stoneWarm-900 truncate">{user.email || user.phone}</p>
                      <span className="inline-block mt-1 text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 bg-brand-50 text-brand-800 rounded-md">
                        {user.role} Access
                      </span>
                    </div>

                    <button
                      onClick={() => {
                        setActiveView('profile');
                        setUserDropdownOpen(false);
                      }}
                      className="w-full text-left px-4 py-2 text-sm text-stoneWarm-700 hover:bg-brand-50/70 hover:text-brand-800 flex items-center space-x-2 transition-colors"
                    >
                      <User className="w-4 h-4 text-brand-600" />
                      <span>Citizen Profile & KYC</span>
                    </button>

                    <button
                      onClick={() => {
                        setActiveView('admin');
                        setUserDropdownOpen(false);
                      }}
                      className="w-full text-left px-4 py-2 text-sm text-stoneWarm-700 hover:bg-brand-50/70 hover:text-brand-800 flex items-center space-x-2 transition-colors"
                    >
                      <LayoutDashboard className="w-4 h-4 text-ochre-600" />
                      <span>Admin & Verification Queue</span>
                    </button>

                    <div className="border-t border-stoneWarm-100 my-1"></div>

                    <button
                      onClick={() => {
                        onLogout();
                        setUserDropdownOpen(false);
                      }}
                      className="w-full text-left px-4 py-2 text-sm text-red-700 hover:bg-red-50 flex items-center space-x-2 transition-colors"
                    >
                      <LogOut className="w-4 h-4 text-red-600" />
                      <span>Sign Out</span>
                    </button>
                  </div>
                )}
              </div>
            ) : (
              <div className="flex items-center space-x-2">
                <button
                  onClick={() => onOpenAuth('login')}
                  className="px-4 py-2 rounded-lg text-sm font-semibold text-stoneWarm-700 hover:text-stoneWarm-900 hover:bg-stoneWarm-100 transition-colors"
                >
                  Sign In
                </button>
                <button
                  onClick={() => onOpenAuth('register')}
                  className="px-4 py-2 rounded-lg text-sm font-semibold bg-brand-600 text-white hover:bg-brand-700 transition-all shadow-subtle flex items-center space-x-1.5"
                >
                  <User className="w-4 h-4" />
                  <span>Register Citizen</span>
                </button>
              </div>
            )}
          </div>

          {/* Mobile menu toggle */}
          <div className="lg:hidden flex items-center space-x-2">
            {user && (
              <button
                onClick={() => setActiveView('profile')}
                className="w-8 h-8 rounded-full bg-brand-600 text-white font-bold text-xs flex items-center justify-center"
              >
                {user.avatarInitials || 'U'}
              </button>
            )}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 rounded-lg text-stoneWarm-700 hover:bg-stoneWarm-100"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>

        </div>
      </div>

      {/* Mobile drop menu */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-stoneWarm-50 border-b border-stoneWarm-200 px-4 pt-2 pb-6 space-y-2">
          <button
            onClick={() => { setActiveView('home'); setMobileMenuOpen(false); }}
            className="w-full text-left px-3 py-2 rounded-lg text-sm font-medium text-stoneWarm-800 hover:bg-brand-50"
          >
            Discover Schemes
          </button>
          <button
            onClick={() => { setActiveView('calculator'); setMobileMenuOpen(false); }}
            className="w-full text-left px-3 py-2 rounded-lg text-sm font-medium text-stoneWarm-800 hover:bg-brand-50 flex items-center space-x-2"
          >
            <Sparkles className="w-4 h-4 text-ochre-500" />
            <span>Eligibility Checker</span>
          </button>
          <button
            onClick={() => { setActiveView('tracker'); setMobileMenuOpen(false); }}
            className="w-full text-left px-3 py-2 rounded-lg text-sm font-medium text-stoneWarm-800 hover:bg-brand-50 flex items-center space-x-2"
          >
            <FileText className="w-4 h-4 text-stoneWarm-500" />
            <span>Track Application</span>
          </button>
          <button
            onClick={() => { setActiveView('profile'); setMobileMenuOpen(false); }}
            className="w-full text-left px-3 py-2 rounded-lg text-sm font-medium text-stoneWarm-800 hover:bg-brand-50 flex items-center space-x-2"
          >
            <User className="w-4 h-4 text-brand-600" />
            <span>Citizen Profile & KYC Locker</span>
          </button>
          <button
            onClick={() => { setActiveView('admin'); setMobileMenuOpen(false); }}
            className="w-full text-left px-3 py-2 rounded-lg text-sm font-medium text-stoneWarm-800 hover:bg-brand-50 flex items-center space-x-2"
          >
            <LayoutDashboard className="w-4 h-4 text-ochre-600" />
            <span>Admin Dashboard</span>
          </button>

          <div className="pt-4 border-t border-stoneWarm-200 flex flex-col space-y-2">
            {!user ? (
              <>
                <button
                  onClick={() => { onOpenAuth('login'); setMobileMenuOpen(false); }}
                  className="w-full py-2.5 rounded-lg text-sm font-medium border border-stoneWarm-300 text-stoneWarm-800 text-center"
                >
                  Sign In
                </button>
                <button
                  onClick={() => { onOpenAuth('register'); setMobileMenuOpen(false); }}
                  className="w-full py-2.5 rounded-lg text-sm font-semibold bg-brand-600 text-white text-center shadow-sm"
                >
                  Register Citizen
                </button>
              </>
            ) : (
              <button
                onClick={() => { onLogout(); setMobileMenuOpen(false); }}
                className="w-full py-2.5 rounded-lg text-sm font-medium text-red-700 bg-red-50 text-center"
              >
                Sign Out
              </button>
            )}
          </div>
        </div>
      )}
    </header>
  );
};
