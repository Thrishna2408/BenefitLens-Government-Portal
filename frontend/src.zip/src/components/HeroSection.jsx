import React from 'react';
import { 
  Search, 
  Sparkles, 
  ShieldCheck, 
  TrendingUp, 
  ArrowRight, 
  FileCheck2, 
  Banknote, 
  Users2,
  Building,
  CheckCircle2
} from 'lucide-react';

export const HeroSection = ({ 
  searchQuery, 
  setSearchQuery, 
  onStartCalculator, 
  onStartTracker, 
  onSelectCategory 
}) => {
  const quickTags = [
    { label: 'Farmer Cash Support', cat: 'Agriculture' },
    { label: '₹5L Health Insurance', cat: 'Healthcare' },
    { label: 'Rooftop Solar Subsidy', cat: 'Housing' },
    { label: 'Women ₹1,250/mo DBT', cat: 'Women & Child' },
    { label: 'MUDRA Business Loan', cat: 'MSME & Business' },
    { label: 'Higher Education Scholarship', cat: 'Education' },
  ];

  return (
    <section className="relative overflow-hidden bg-gradient-to-b from-brand-50/70 via-stoneWarm-50 to-stoneWarm-100/60 pt-10 pb-16 border-b border-stoneWarm-200/70">
      {/* Decorative subtle background elements */}
      <div className="absolute top-0 right-0 -mr-20 -mt-20 w-96 h-96 rounded-full bg-brand-200/20 blur-3xl pointer-events-none"></div>
      <div className="absolute bottom-0 left-10 w-80 h-80 rounded-full bg-ochre-200/20 blur-3xl pointer-events-none"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* National Welfare Trust Badge */}
        <div className="flex justify-center">
          <div className="inline-flex items-center space-x-2 px-3.5 py-1.5 rounded-full bg-white border border-stoneWarm-200/90 shadow-subtle text-xs font-semibold text-stoneWarm-800 animate-subtle-pulse">
            <span className="flex h-2 w-2 rounded-full bg-brand-600"></span>
            <span className="text-brand-700">Central & State Scheme Aggregator</span>
            <span className="text-stoneWarm-300">|</span>
            <span className="text-stoneWarm-600">Direct Benefit Transfer (DBT) Enabled</span>
          </div>
        </div>

        {/* Hero Title & Subtitle */}
        <div className="text-center mt-6 max-w-3xl mx-auto">
          <h1 className="text-3xl sm:text-4xl lg:text-5xl font-display font-extrabold text-stoneWarm-900 tracking-tight leading-[1.15]">
            Every government scheme you deserve, <br className="hidden sm:inline" />
            <span className="bg-gradient-to-r from-brand-600 via-brand-700 to-ochre-600 bg-clip-text text-transparent">
              one unified bridge away.
            </span>
          </h1>
          <p className="mt-4 text-base sm:text-lg text-stoneWarm-600 leading-relaxed font-normal">
            Discover all eligible central and state welfare benefits matched to your profile, apply with guided checklists, and follow payments from sanction to direct bank credit.
          </p>
        </div>

        {/* Dynamic Search Box */}
        <div className="mt-8 max-w-2xl mx-auto">
          <div className="relative flex items-center shadow-card rounded-2xl bg-white border border-stoneWarm-300/80 p-2 focus-within:ring-2 focus-within:ring-brand-500 focus-within:border-brand-500 transition-all">
            <div className="pl-3 text-stoneWarm-400">
              <Search className="w-5 h-5 text-brand-600" />
            </div>
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search by scheme name, ministry, or benefit (e.g. Kisan, Solar, Ayushman, Loan)..."
              className="w-full px-3 py-2.5 text-sm sm:text-base text-stoneWarm-900 placeholder-stoneWarm-400 bg-transparent border-none focus:outline-none focus:ring-0"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="px-2 text-stoneWarm-400 hover:text-stoneWarm-600 text-xs font-semibold"
              >
                Clear
              </button>
            )}
            <button
              onClick={() => {
                const el = document.getElementById('schemes-catalog');
                if (el) el.scrollIntoView({ behavior: 'smooth' });
              }}
              className="hidden sm:inline-flex items-center space-x-1 px-4 py-2.5 rounded-xl bg-brand-600 hover:bg-brand-700 text-white font-medium text-sm transition-all shadow-subtle flex-shrink-0"
            >
              <span>Explore</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>

          {/* Quick Filter Tags */}
          <div className="mt-3 flex flex-wrap items-center justify-center gap-2">
            <span className="text-xs text-stoneWarm-500 font-medium mr-1">Popular:</span>
            {quickTags.map((tag, idx) => (
              <button
                key={idx}
                onClick={() => onSelectCategory(tag.cat)}
                className="text-xs px-2.5 py-1 rounded-full bg-stoneWarm-100 hover:bg-brand-100 text-stoneWarm-700 hover:text-brand-800 border border-stoneWarm-200/80 transition-colors"
              >
                {tag.label}
              </button>
            ))}
          </div>
        </div>

        {/* Dual Call-to-Action Hub */}
        <div className="mt-10 flex flex-col sm:flex-row items-center justify-center gap-4 max-w-lg mx-auto">
          <button
            onClick={onStartCalculator}
            className="w-full sm:w-auto px-6 py-3.5 rounded-xl bg-brand-600 hover:bg-brand-700 text-white font-semibold text-sm transition-all shadow-card flex items-center justify-center space-x-2 group hover:-translate-y-0.5"
          >
            <Sparkles className="w-4 h-4 text-ochre-300 group-hover:rotate-12 transition-transform" />
            <span>Check My Scheme Eligibility</span>
            <ArrowRight className="w-4 h-4 opacity-70 group-hover:translate-x-1 transition-transform" />
          </button>

          <button
            onClick={onStartTracker}
            className="w-full sm:w-auto px-6 py-3.5 rounded-xl bg-white hover:bg-stoneWarm-100 text-stoneWarm-800 font-semibold text-sm transition-all border border-stoneWarm-300 shadow-subtle flex items-center justify-center space-x-2"
          >
            <FileCheck2 className="w-4 h-4 text-stoneWarm-600" />
            <span>Track Application by ID</span>
          </button>
        </div>

        {/* 4 Pillars Trust Ribbon */}
        <div className="mt-14 pt-8 border-t border-stoneWarm-200/70 grid grid-cols-2 md:grid-cols-4 gap-4 sm:gap-6">
          <div className="bg-white/70 backdrop-blur-sm p-4 rounded-xl border border-stoneWarm-200 shadow-subtle flex items-center space-x-3">
            <div className="w-10 h-10 rounded-lg bg-brand-100 text-brand-700 flex items-center justify-center flex-shrink-0">
              <Building className="w-5 h-5" />
            </div>
            <div>
              <p className="text-base sm:text-lg font-bold text-stoneWarm-900 font-display">500+ Schemes</p>
              <p className="text-xs text-stoneWarm-500">Central & State Combined</p>
            </div>
          </div>

          <div className="bg-white/70 backdrop-blur-sm p-4 rounded-xl border border-stoneWarm-200 shadow-subtle flex items-center space-x-3">
            <div className="w-10 h-10 rounded-lg bg-ochre-100 text-ochre-700 flex items-center justify-center flex-shrink-0">
              <Banknote className="w-5 h-5" />
            </div>
            <div>
              <p className="text-base sm:text-lg font-bold text-stoneWarm-900 font-display">₹3.2 Lakh Cr</p>
              <p className="text-xs text-stoneWarm-500">Sanctioned Benefits</p>
            </div>
          </div>

          <div className="bg-white/70 backdrop-blur-sm p-4 rounded-xl border border-stoneWarm-200 shadow-subtle flex items-center space-x-3">
            <div className="w-10 h-10 rounded-lg bg-brand-100 text-brand-700 flex items-center justify-center flex-shrink-0">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <p className="text-base sm:text-lg font-bold text-stoneWarm-900 font-display">100% Direct DBT</p>
              <p className="text-xs text-stoneWarm-500">Aadhaar NPCI Credited</p>
            </div>
          </div>

          <div className="bg-white/70 backdrop-blur-sm p-4 rounded-xl border border-stoneWarm-200 shadow-subtle flex items-center space-x-3">
            <div className="w-10 h-10 rounded-lg bg-stoneWarm-200 text-stoneWarm-700 flex items-center justify-center flex-shrink-0">
              <CheckCircle2 className="w-5 h-5" />
            </div>
            <div>
              <p className="text-base sm:text-lg font-bold text-stoneWarm-900 font-display">Zero Middlemen</p>
              <p className="text-xs text-stoneWarm-500">Paperless & Transparent</p>
            </div>
          </div>
        </div>

      </div>
    </section>
  );
};
