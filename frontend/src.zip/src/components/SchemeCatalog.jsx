import React, { useState, useMemo } from 'react';
import { 
  Sprout, 
  HeartPulse, 
  Users, 
  GraduationCap, 
  Home, 
  Briefcase, 
  ShieldCheck, 
  LayoutGrid, 
  ArrowRight, 
  Filter, 
  MapPin, 
  CheckCircle, 
  Sparkles,
  Info,
  Calendar,
  Layers
} from 'lucide-react';
import { CATEGORIES } from '../data/mockData';

const iconMap = {
  LayoutGrid,
  Sprout,
  HeartPulse,
  Users,
  GraduationCap,
  Home,
  Briefcase,
  ShieldCheck
};

export const SchemeCatalog = ({ 
  schemes, 
  searchQuery, 
  setSearchQuery, 
  selectedCategory, 
  setSelectedCategory,
  onOpenSchemeDetails,
  onQuickApply
}) => {
  const [levelFilter, setLevelFilter] = useState('All'); // 'All', 'Central', 'State'
  const [selectedState, setSelectedState] = useState('All');

  const statesList = [
    'All',
    'Madhya Pradesh',
    'Karnataka',
    'Maharashtra',
    'Uttar Pradesh',
    'Rajasthan',
    'Tamil Nadu',
    'Bihar'
  ];

  const filteredSchemes = useMemo(() => {
    return schemes.filter((s) => {
      // Category check
      if (selectedCategory !== 'all' && s.category !== selectedCategory) {
        return false;
      }
      // Level check
      if (levelFilter !== 'All' && s.level !== levelFilter) {
        return false;
      }
      // State check
      if (selectedState !== 'All' && s.state !== selectedState && s.state !== 'All India') {
        return false;
      }
      // Query check
      if (searchQuery.trim() !== '') {
        const q = searchQuery.toLowerCase();
        const matchTitle = s.title.toLowerCase().includes(q);
        const matchMinistry = s.ministry.toLowerCase().includes(q);
        const matchDesc = s.shortDescription.toLowerCase().includes(q);
        const matchCategory = s.category.toLowerCase().includes(q);
        const matchBenefit = s.benefit.toLowerCase().includes(q);
        return matchTitle || matchMinistry || matchDesc || matchCategory || matchBenefit;
      }
      return true;
    });
  }, [schemes, selectedCategory, levelFilter, selectedState, searchQuery]);

  return (
    <section id="schemes-catalog" className="py-12 bg-stoneWarm-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-8 pb-4 border-b border-stoneWarm-200">
          <div>
            <div className="flex items-center space-x-2 text-brand-700 font-semibold text-xs uppercase tracking-wider">
              <Layers className="w-4 h-4" />
              <span>Government Schemes Directory</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-display font-bold text-stoneWarm-900 mt-1">
              Explore Central & State Schemes
            </h2>
            <p className="text-stoneWarm-600 text-sm mt-1 max-w-2xl">
              Browse actively running welfare programs verified with Direct Benefit Transfer (DBT) and e-KYC integration.
            </p>
          </div>

          <div className="mt-4 md:mt-0 flex items-center space-x-2 text-xs text-stoneWarm-500 font-medium">
            <span>Showing <strong className="text-stoneWarm-900">{filteredSchemes.length}</strong> active schemes</span>
          </div>
        </div>

        {/* Category Filter Pills */}
        <div className="flex items-center space-x-2 overflow-x-auto pb-3 mb-6 scrollbar-none">
          {CATEGORIES.map((cat) => {
            const Icon = iconMap[cat.icon] || LayoutGrid;
            const isSelected = selectedCategory === cat.id || (cat.id === 'all' && selectedCategory === 'all');
            return (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id)}
                className={`flex items-center space-x-2 px-4 py-2 rounded-xl text-xs sm:text-sm font-medium whitespace-nowrap transition-all flex-shrink-0 ${
                  isSelected
                    ? 'bg-brand-600 text-white shadow-subtle'
                    : 'bg-white text-stoneWarm-700 hover:bg-stoneWarm-100/80 border border-stoneWarm-200/90'
                }`}
              >
                <Icon className="w-4 h-4" />
                <span>{cat.name}</span>
              </button>
            );
          })}
        </div>

        {/* Secondary Filters Bar (Level & State) */}
        <div className="bg-white p-3 rounded-2xl border border-stoneWarm-200 shadow-subtle mb-8 flex flex-wrap items-center justify-between gap-3">
          
          {/* Level Filter Buttons */}
          <div className="flex items-center space-x-1.5">
            <span className="text-xs font-semibold text-stoneWarm-500 mr-1 flex items-center">
              <Filter className="w-3.5 h-3.5 mr-1" />
              Level:
            </span>
            {['All', 'Central', 'State'].map((lvl) => (
              <button
                key={lvl}
                onClick={() => setLevelFilter(lvl)}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                  levelFilter === lvl
                    ? 'bg-stoneWarm-800 text-stoneWarm-50 font-semibold'
                    : 'bg-stoneWarm-100 text-stoneWarm-700 hover:bg-stoneWarm-200'
                }`}
              >
                {lvl === 'All' ? 'All Levels' : lvl}
              </button>
            ))}
          </div>

          {/* State Dropdown Filter */}
          <div className="flex items-center space-x-2">
            <span className="text-xs font-semibold text-stoneWarm-500 flex items-center">
              <MapPin className="w-3.5 h-3.5 mr-1 text-ochre-600" />
              State:
            </span>
            <select
              value={selectedState}
              onChange={(e) => setSelectedState(e.target.value)}
              className="px-3 py-1.5 rounded-lg text-xs font-medium bg-stoneWarm-100 border border-stoneWarm-200 text-stoneWarm-800 focus:outline-none focus:ring-1 focus:ring-brand-500"
            >
              {statesList.map((st) => (
                <option key={st} value={st}>
                  {st === 'All' ? 'All States (Pan-India)' : st}
                </option>
              ))}
            </select>
          </div>

        </div>

        {/* Schemes Grid */}
        {filteredSchemes.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredSchemes.map((scheme) => (
              <div
                key={scheme.id}
                className="bg-white rounded-2xl border border-stoneWarm-200/90 shadow-subtle hover:shadow-card hover:border-brand-300 transition-all flex flex-col justify-between overflow-hidden group"
              >
                <div className="p-6">
                  {/* Top Badges */}
                  <div className="flex items-center justify-between gap-2 mb-3">
                    <span className={`text-[11px] font-bold uppercase tracking-wider px-2.5 py-0.5 rounded-md ${
                      scheme.level === 'Central'
                        ? 'bg-brand-50 text-brand-800 border border-brand-200/60'
                        : 'bg-ochre-50 text-ochre-800 border border-ochre-200/60'
                    }`}>
                      {scheme.level} Scheme • {scheme.state}
                    </span>
                    <span className="text-[11px] font-medium text-stoneWarm-500 bg-stoneWarm-100 px-2 py-0.5 rounded">
                      {scheme.category}
                    </span>
                  </div>

                  {/* Ministry */}
                  <p className="text-xs text-stoneWarm-500 font-medium truncate mb-1">
                    {scheme.ministry}
                  </p>

                  {/* Scheme Title */}
                  <h3 className="text-lg font-display font-bold text-stoneWarm-900 group-hover:text-brand-700 transition-colors leading-snug mb-2">
                    {scheme.title}
                  </h3>

                  {/* Benefit Card Ribbon */}
                  <div className="bg-gradient-to-r from-brand-50/70 via-ochre-50/50 to-stoneWarm-100/50 border border-brand-200/50 rounded-xl p-3 mb-4">
                    <p className="text-[11px] font-semibold uppercase tracking-wider text-brand-800">
                      Direct Financial Benefit
                    </p>
                    <p className="text-base font-bold text-stoneWarm-900 mt-0.5">
                      {scheme.benefit}
                    </p>
                    <p className="text-xs text-stoneWarm-600 mt-0.5 line-clamp-1">
                      {scheme.benefitType}
                    </p>
                  </div>

                  {/* Description */}
                  <p className="text-xs text-stoneWarm-600 leading-relaxed line-clamp-3 mb-4">
                    {scheme.shortDescription}
                  </p>

                  {/* Eligibility Quick Tags */}
                  <div className="space-y-1.5 pt-3 border-t border-stoneWarm-100 text-xs text-stoneWarm-600">
                    <div className="flex items-center space-x-1.5">
                      <span className="font-medium text-stoneWarm-500">Eligibility:</span>
                      <span className="text-stoneWarm-800 font-semibold truncate">
                        Age {scheme.eligibility.minAge}-{scheme.eligibility.maxAge} yrs • {scheme.eligibility.gender}
                      </span>
                    </div>
                    <div className="flex items-center space-x-1.5">
                      <span className="font-medium text-stoneWarm-500">Documents:</span>
                      <span className="text-stoneWarm-700 truncate">
                        {scheme.documents.slice(0, 2).join(', ')} +{scheme.documents.length - 2} more
                      </span>
                    </div>
                  </div>
                </div>

                {/* Card Action Buttons Footer */}
                <div className="p-4 bg-stoneWarm-50/80 border-t border-stoneWarm-200/80 flex items-center space-x-2">
                  <button
                    onClick={() => onOpenSchemeDetails(scheme)}
                    className="flex-1 py-2.5 px-3 rounded-xl text-xs font-semibold text-stoneWarm-800 bg-white hover:bg-stoneWarm-100 border border-stoneWarm-300 transition-colors text-center shadow-subtle"
                  >
                    View Guidelines
                  </button>

                  <button
                    onClick={() => onQuickApply(scheme)}
                    className="flex-1 py-2.5 px-3 rounded-xl text-xs font-semibold text-white bg-brand-600 hover:bg-brand-700 transition-all shadow-subtle flex items-center justify-center space-x-1 group/btn"
                  >
                    <span>Apply Online</span>
                    <ArrowRight className="w-3.5 h-3.5 group-hover/btn:translate-x-0.5 transition-transform" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="bg-white rounded-2xl border border-stoneWarm-200 p-12 text-center max-w-lg mx-auto shadow-subtle">
            <div className="w-12 h-12 rounded-full bg-stoneWarm-100 text-stoneWarm-400 flex items-center justify-center mx-auto mb-4">
              <Info className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-bold text-stoneWarm-900">No matching schemes found</h3>
            <p className="text-xs text-stoneWarm-500 mt-1">
              Try adjusting your search terms or clearing selected category and state filters.
            </p>
            <button
              onClick={() => {
                setSearchQuery('');
                setSelectedCategory('all');
                setLevelFilter('All');
                setSelectedState('All');
              }}
              className="mt-4 px-4 py-2 rounded-xl bg-brand-600 text-white text-xs font-semibold hover:bg-brand-700 transition-colors"
            >
              Reset All Filters
            </button>
          </div>
        )}

      </div>
    </section>
  );
};
