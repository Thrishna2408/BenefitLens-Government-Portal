import React, { useState } from 'react';
import { 
  Search, 
  FileCheck, 
  CheckCircle2, 
  Clock, 
  AlertCircle, 
  Banknote, 
  Building, 
  User, 
  ChevronRight, 
  Printer, 
  Download,
  ShieldCheck,
  Calendar
} from 'lucide-react';

export const TrackApplicationWidget = ({ applications, onOpenDetails }) => {
  const [searchId, setSearchId] = useState('');
  const [searchedResult, setSearchedResult] = useState(null);
  const [hasSearched, setHasSearched] = useState(false);

  const handleSearch = (e) => {
    e.preventDefault();
    if (!searchId.trim()) return;

    setHasSearched(true);
    const found = applications.find(
      (app) => app.id.toLowerCase() === searchId.trim().toLowerCase() ||
               app.aadhaarMasked.includes(searchId.trim())
    );
    setSearchedResult(found || null);
  };

  const getStatusBadge = (status) => {
    switch (status) {
      case 'Approved':
      case 'Disbursed':
        return (
          <span className="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-bold bg-brand-100 text-brand-800 border border-brand-200">
            <CheckCircle2 className="w-3.5 h-3.5 mr-1 text-brand-600" />
            {status}
          </span>
        );
      case 'Under Review':
        return (
          <span className="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-bold bg-ochre-100 text-ochre-800 border border-ochre-200">
            <Clock className="w-3.5 h-3.5 mr-1 text-ochre-600" />
            Under Verification
          </span>
        );
      case 'Documents Required':
        return (
          <span className="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-bold bg-amber-100 text-amber-900 border border-amber-300">
            <AlertCircle className="w-3.5 h-3.5 mr-1 text-amber-700" />
            Action Required
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-bold bg-stoneWarm-200 text-stoneWarm-800">
            {status}
          </span>
        );
    }
  };

  return (
    <section className="py-12 bg-stoneWarm-50 min-h-[550px]">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center space-x-1.5 px-3 py-1 rounded-full bg-brand-100 text-brand-800 text-xs font-semibold mb-2">
            <FileCheck className="w-3.5 h-3.5" />
            <span>Public Application Tracker</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-display font-extrabold text-stoneWarm-900">
            Track Scheme Sanction & DBT Payment
          </h2>
          <p className="text-stoneWarm-600 text-xs sm:text-sm mt-1 max-w-xl mx-auto">
            Enter your SchemeSetu Reference ID (e.g. <span className="font-mono font-semibold text-brand-700">SS-2026-89412</span>) or last 4 digits of Aadhaar to check real-time progress.
          </p>
        </div>

        {/* Search Bar */}
        <form onSubmit={handleSearch} className="mb-8 max-w-xl mx-auto">
          <div className="flex items-center bg-white border border-stoneWarm-300 rounded-2xl p-2 shadow-card focus-within:ring-2 focus-within:ring-brand-500 transition-all">
            <Search className="w-5 h-5 text-brand-600 ml-2" />
            <input
              type="text"
              value={searchId}
              onChange={(e) => setSearchId(e.target.value)}
              placeholder="e.g. SS-2026-89412 or SS-2026-77341"
              className="w-full px-3 py-2 text-sm text-stoneWarm-900 placeholder-stoneWarm-400 bg-transparent border-none focus:outline-none"
            />
            <button
              type="submit"
              className="px-5 py-2.5 rounded-xl bg-brand-600 hover:bg-brand-700 text-white font-semibold text-xs transition-all shadow-subtle flex-shrink-0"
            >
              Track Status
            </button>
          </div>

          {/* Quick preset chips */}
          <div className="flex items-center justify-center space-x-2 mt-3 text-xs text-stoneWarm-500">
            <span>Try sample tracking IDs:</span>
            <button
              type="button"
              onClick={() => setSearchId('SS-2026-89412')}
              className="text-brand-700 font-mono font-semibold underline hover:text-brand-800"
            >
              SS-2026-89412
            </button>
            <span>•</span>
            <button
              type="button"
              onClick={() => setSearchId('SS-2026-77341')}
              className="text-brand-700 font-mono font-semibold underline hover:text-brand-800"
            >
              SS-2026-77341
            </button>
          </div>
        </form>

        {/* Results Card */}
        {hasSearched && searchedResult ? (
          <div className="bg-white rounded-3xl border border-stoneWarm-200 shadow-card overflow-hidden animate-fadeIn">
            
            {/* Top Status Banner */}
            <div className="bg-stoneWarm-50 border-b border-stoneWarm-200 p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <div className="flex items-center space-x-2">
                  <span className="text-xs font-mono font-bold text-stoneWarm-600 bg-stoneWarm-200/80 px-2.5 py-0.5 rounded">
                    {searchedResult.id}
                  </span>
                  {getStatusBadge(searchedResult.status)}
                </div>
                <h3 className="text-lg sm:text-xl font-bold text-stoneWarm-900 mt-2 font-display">
                  {searchedResult.schemeTitle}
                </h3>
                <p className="text-xs text-stoneWarm-500 mt-0.5">
                  Applied on {searchedResult.appliedDate} by <strong>{searchedResult.applicantName}</strong> (Aadhaar: {searchedResult.aadhaarMasked})
                </p>
              </div>

              <div className="text-right sm:border-l sm:border-stoneWarm-200 sm:pl-6">
                <span className="text-xs text-stoneWarm-500 font-medium block">Sanctioned Entitlement</span>
                <span className="text-lg font-bold text-brand-700 font-display">
                  {searchedResult.disbursedAmount}
                </span>
                {searchedResult.nextInstallmentDate && (
                  <span className="text-[11px] text-stoneWarm-500 block mt-0.5">
                    Next release: {searchedResult.nextInstallmentDate}
                  </span>
                )}
              </div>
            </div>

            {/* Stepper Timeline */}
            <div className="p-6 sm:p-8">
              <h4 className="text-xs font-bold uppercase tracking-wider text-stoneWarm-500 mb-6 flex items-center space-x-1.5">
                <Clock className="w-4 h-4 text-brand-600" />
                <span>Four-Stage Verification & DBT Timeline</span>
              </h4>

              <div className="relative pl-6 sm:pl-8 border-l-2 border-brand-200 space-y-8 ml-3">
                {searchedResult.timeline.map((step, idx) => (
                  <div key={idx} className="relative group">
                    {/* Node Dot */}
                    <div className={`absolute -left-[31px] sm:-left-[39px] top-0.5 w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold transition-all ${
                      step.done
                        ? 'bg-brand-600 text-white shadow-subtle'
                        : 'bg-stoneWarm-100 border-2 border-stoneWarm-300 text-stoneWarm-500'
                    }`}>
                      {step.done ? '✓' : step.stage}
                    </div>

                    <div>
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between">
                        <h5 className={`text-sm font-bold ${
                          step.done ? 'text-stoneWarm-900' : 'text-stoneWarm-500'
                        }`}>
                          {step.title}
                        </h5>
                        <span className="text-xs text-stoneWarm-400 font-medium mt-0.5 sm:mt-0">
                          {step.date}
                        </span>
                      </div>
                      <p className="text-xs text-stoneWarm-600 mt-1">
                        {step.desc}
                      </p>
                    </div>
                  </div>
                ))}
              </div>

              {/* Officer Remarks Box */}
              {searchedResult.officerRemarks && (
                <div className="mt-8 p-4 rounded-xl bg-stoneWarm-50 border border-stoneWarm-200 flex items-start space-x-3">
                  <ShieldCheck className="w-5 h-5 text-brand-600 flex-shrink-0 mt-0.5" />
                  <div>
                    <h5 className="text-xs font-bold text-stoneWarm-900 uppercase tracking-wider">
                      Official Desk Remarks:
                    </h5>
                    <p className="text-xs text-stoneWarm-700 mt-0.5 leading-relaxed">
                      {searchedResult.officerRemarks}
                    </p>
                  </div>
                </div>
              )}

              {/* Action Buttons */}
              <div className="mt-6 pt-6 border-t border-stoneWarm-100 flex flex-wrap justify-between items-center gap-3">
                <div className="text-xs text-stoneWarm-500">
                  Direct inquiries? Call helpline: <strong className="text-stoneWarm-800">1800-11-7788</strong>
                </div>
                <button
                  onClick={() => alert(`Printing status slip for ${searchedResult.id}`)}
                  className="px-4 py-2 rounded-xl bg-stoneWarm-100 hover:bg-stoneWarm-200 text-stoneWarm-800 text-xs font-semibold flex items-center space-x-1.5 transition-colors"
                >
                  <Printer className="w-3.5 h-3.5" />
                  <span>Print Acknowledgment Slip</span>
                </button>
              </div>

            </div>

          </div>
        ) : hasSearched && !searchedResult ? (
          <div className="bg-white rounded-3xl border border-stoneWarm-200 p-8 text-center max-w-md mx-auto shadow-subtle animate-fadeIn">
            <div className="w-12 h-12 rounded-full bg-red-50 text-red-500 flex items-center justify-center mx-auto mb-3">
              <AlertCircle className="w-6 h-6" />
            </div>
            <h3 className="text-base font-bold text-stoneWarm-900">Application Record Not Found</h3>
            <p className="text-xs text-stoneWarm-500 mt-1">
              No matching record found for <strong className="font-mono text-stoneWarm-800">"{searchId}"</strong>. Please verify the reference number printed on your submission receipt.
            </p>
          </div>
        ) : null}

      </div>
    </section>
  );
};
