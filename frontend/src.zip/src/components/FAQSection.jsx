import React, { useState } from 'react';
import { ChevronDown, HelpCircle, ShieldCheck, Sparkles, PhoneCall } from 'lucide-react';

export const FAQSection = ({ onOpenGrievance }) => {
  const [openIdx, setOpenIdx] = useState(0);

  const faqs = [
    {
      q: 'How does SchemeSetu match schemes to my profile with 100% accuracy?',
      a: 'SchemeSetu parses all central and state welfare guidelines and matches them in real-time against your age, social category (OBC/SC/ST/EWS/General), state of domicile, landholding, and family annual income. It removes any guesswork or complex paperwork.'
    },
    {
      q: 'What is Direct Benefit Transfer (DBT) and how is money credited to my bank?',
      a: 'DBT transfers welfare subsidies and financial assistance directly from the Consolidated Fund of India or State Treasuries into your Aadhaar-seeded bank account through NPCI (National Payments Corporation of India), ensuring zero middlemen.'
    },
    {
      q: 'How does DigiLocker integration help prevent application rejections?',
      a: 'When you attach documents like your Aadhaar, Land Khatauni, or Tehsildar Income Certificate via DigiLocker, they are cryptographically pre-verified. This prevents desk rejections caused by illegible photocopies or missing stamps.'
    },
    {
      q: 'How can I track the exact stage of my submitted application?',
      a: 'Every application is issued a unique Reference ID (e.g. SS-2026-89412). You can enter this ID on the "Track Application" page anytime to see whether it is under desk review, department sanction, or scheduled for bank credit.'
    },
    {
      q: 'Is there any service charge or application fee on SchemeSetu?',
      a: 'No. SchemeSetu is an open citizen welfare bridge provided 100% free of cost. Never pay any fee or bribe to anyone claiming to expedite government scheme approvals.'
    }
  ];

  return (
    <section className="py-16 bg-white border-t border-stoneWarm-200">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="text-center mb-10">
          <div className="inline-flex items-center space-x-1.5 px-3 py-1 rounded-full bg-brand-50 text-brand-800 border border-brand-200 text-xs font-semibold mb-2">
            <HelpCircle className="w-3.5 h-3.5" />
            <span>Citizen Help & Knowledge Base</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-display font-extrabold text-stoneWarm-900">
            Frequently Asked Questions
          </h2>
          <p className="text-stoneWarm-500 text-xs sm:text-sm mt-1">
            Everything you need to know about eligibility, DigiLocker verification, and direct bank transfers.
          </p>
        </div>

        <div className="space-y-3">
          {faqs.map((faq, idx) => {
            const isOpen = openIdx === idx;
            return (
              <div
                key={idx}
                className="rounded-2xl border border-stoneWarm-200 bg-stoneWarm-50/60 overflow-hidden transition-all"
              >
                <button
                  onClick={() => setOpenIdx(isOpen ? -1 : idx)}
                  className="w-full p-4 sm:p-5 text-left flex justify-between items-center space-x-4 hover:bg-stoneWarm-100/70 transition-colors"
                >
                  <span className="text-sm sm:text-base font-bold text-stoneWarm-900">
                    {faq.q}
                  </span>
                  <ChevronDown className={`w-5 h-5 text-stoneWarm-500 transition-transform duration-200 flex-shrink-0 ${
                    isOpen ? 'rotate-180 text-brand-600' : ''
                  }`} />
                </button>

                {isOpen && (
                  <div className="px-5 pb-5 pt-1 text-xs sm:text-sm text-stoneWarm-700 leading-relaxed border-t border-stoneWarm-200/60 bg-white">
                    {faq.a}
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* Support Banner */}
        <div className="mt-10 p-6 rounded-3xl bg-stoneWarm-100 border border-stoneWarm-200 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-full bg-brand-600 text-white flex items-center justify-center flex-shrink-0">
              <PhoneCall className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-sm font-bold text-stoneWarm-900">Have a question or unresolved grievance?</h4>
              <p className="text-xs text-stoneWarm-600">Our citizen support cell is available 24x7 toll-free at <strong>1800-11-7788</strong>.</p>
            </div>
          </div>

          <button
            onClick={onOpenGrievance}
            className="px-4 py-2.5 rounded-xl bg-stoneWarm-900 hover:bg-stoneWarm-800 text-white text-xs font-semibold whitespace-nowrap shadow-subtle"
          >
            Lodge a Grievance
          </button>
        </div>

      </div>
    </section>
  );
};
