import React from 'react';
import { Building2, ShieldCheck, Phone, Mail, Globe, Heart } from 'lucide-react';

export const Footer = ({ onOpenGrievance, onStartCalculator, onStartTracker, setActiveView }) => {
  return (
    <footer className="bg-stoneWarm-900 text-stoneWarm-300 pt-12 pb-8 border-t border-stoneWarm-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Main 4-column footer */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 pb-10 border-b border-stoneWarm-800">
          
          {/* Col 1: Brand & National Emblem info */}
          <div className="space-y-3">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 rounded-xl bg-brand-600 text-white flex items-center justify-center font-bold font-display text-xl">
                स
              </div>
              <span className="font-display font-bold text-xl text-white tracking-tight">
                Scheme<span className="text-brand-400">Setu</span>
              </span>
            </div>
            <p className="text-xs text-stoneWarm-400 leading-relaxed">
              Unified National Portal for Central & State Welfare Schemes, Eligibility Discovery, DigiLocker Verification, and Direct Benefit Transfer (DBT).
            </p>
            <div className="flex items-center space-x-2 text-[11px] text-ochre-400">
              <ShieldCheck className="w-4 h-4" />
              <span>Government of India & State Partnerships</span>
            </div>
          </div>

          {/* Col 2: Citizen Portals */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-white mb-3">
              Citizen Services
            </h4>
            <ul className="space-y-2 text-xs text-stoneWarm-400">
              <li>
                <button onClick={() => setActiveView('home')} className="hover:text-white transition-colors">
                  Explore Welfare Directory
                </button>
              </li>
              <li>
                <button onClick={onStartCalculator} className="hover:text-white transition-colors">
                  AI Eligibility Checker
                </button>
              </li>
              <li>
                <button onClick={onStartTracker} className="hover:text-white transition-colors">
                  Track Application by ID
                </button>
              </li>
              <li>
                <button onClick={() => setActiveView('profile')} className="hover:text-white transition-colors">
                  Digital KYC Document Locker
                </button>
              </li>
            </ul>
          </div>

          {/* Col 3: Key Welfare Sectors */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-white mb-3">
              Welfare Categories
            </h4>
            <ul className="space-y-2 text-xs text-stoneWarm-400">
              <li>PM-KISAN & Agriculture Subsidies</li>
              <li>Ayushman Bharat & Health Coverage</li>
              <li>PMAY Housing & Rural Pucca Homes</li>
              <li>MUDRA & PM Vishwakarma Loans</li>
              <li>Post-Matric National Scholarships</li>
            </ul>
          </div>

          {/* Col 4: Helplines & Grievances */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-white mb-3">
              Helpdesk & Support
            </h4>
            <div className="space-y-2 text-xs text-stoneWarm-400">
              <div className="flex items-center space-x-2 text-white font-semibold">
                <Phone className="w-4 h-4 text-brand-400" />
                <span>1800-11-7788 (Toll Free)</span>
              </div>
              <p className="text-[11px]">24x7 Citizen Assistance in 12 Indian Languages</p>
              <div className="pt-2">
                <button
                  onClick={onOpenGrievance}
                  className="px-3 py-1.5 rounded-lg bg-stoneWarm-800 hover:bg-stoneWarm-700 text-ochre-300 text-xs font-semibold border border-stoneWarm-700 transition-colors"
                >
                  CPGRAMS Public Grievance
                </button>
              </div>
            </div>
          </div>

        </div>

        {/* Bottom micro footer */}
        <div className="pt-6 flex flex-col sm:flex-row items-center justify-between text-xs text-stoneWarm-500 gap-3">
          <p>© 2026 SchemeSetu Team • Designed for Inclusive Citizen Welfare</p>
          <div className="flex space-x-4">
            <span className="hover:text-stoneWarm-300 cursor-pointer">Privacy Policy</span>
            <span>•</span>
            <span className="hover:text-stoneWarm-300 cursor-pointer">Terms of Service</span>
            <span>•</span>
            <span className="hover:text-stoneWarm-300 cursor-pointer">Hyperlinking Policy</span>
          </div>
        </div>

      </div>
    </footer>
  );
};
