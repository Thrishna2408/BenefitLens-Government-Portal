import React, { useState } from 'react';
import { 
  X, 
  CheckCircle2, 
  FileText, 
  Building, 
  Sparkles, 
  ArrowRight, 
  ArrowLeft, 
  UploadCloud, 
  Check, 
  ShieldCheck, 
  AlertCircle,
  Download,
  Printer
} from 'lucide-react';
import confetti from 'canvas-confetti';

export const SchemeDetailsModal = ({ 
  scheme, 
  isOpen, 
  onClose, 
  user, 
  onApplicationSubmitted 
}) => {
  const [activeTab, setActiveTab] = useState('details'); // 'details' or 'apply'
  const [applyStep, setApplyStep] = useState(1);
  const [formData, setFormData] = useState({
    fullName: user ? user.name : 'Rajesh Kumar Verma',
    aadhaarNumber: user ? user.aadhaarNumber : 'XXXX-XXXX-4819',
    mobileNumber: user ? user.phone : '+91 98765 43210',
    email: user ? user.email : 'rajesh.verma@example.in',
    socialCategory: user ? user.category : 'OBC',
    annualIncome: user ? user.annualIncome : '₹ 2,40,000',
    occupation: user ? user.occupation : 'Farmer',
    state: user ? user.state : 'Madhya Pradesh',
    district: user ? user.district : 'Indore',
    bankName: user ? user.bankName : 'State Bank of India',
    accountNumber: user ? user.accountNumber : '••••••••4102',
    ifscCode: user ? user.ifscCode : 'SBIN0001842',
    attachedDocs: ['Aadhaar Card (Verified)', 'Income Certificate (DigiLocker)'],
    declarationAgreed: true
  });
  const [submittedAppId, setSubmittedAppId] = useState(null);

  if (!isOpen || !scheme) return null;

  const handleInputChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleFinalSubmit = (e) => {
    e.preventDefault();
    const newId = `SS-2026-${Math.floor(10000 + Math.random() * 90000)}`;
    setSubmittedAppId(newId);
    
    // Trigger celebration confetti
    try {
      confetti({
        particleCount: 80,
        spread: 70,
        origin: { y: 0.6 }
      });
    } catch (err) {
      // ignore
    }

    const newApp = {
      id: newId,
      schemeId: scheme.id,
      schemeTitle: scheme.title,
      applicantName: formData.fullName,
      aadhaarMasked: formData.aadhaarNumber,
      category: formData.socialCategory,
      appliedDate: new Date().toISOString().split('T')[0],
      status: 'Under Review',
      currentStage: 1,
      disbursedAmount: scheme.benefit,
      officerRemarks: 'Online application submitted with Aadhaar e-KYC. Pending District Officer desk verification.',
      timeline: [
        { stage: 1, title: 'Application Submitted Online', date: 'Just now', done: true, desc: `Reference ID ${newId} assigned. e-KYC authenticated.` },
        { stage: 2, title: 'Document & Eligibility Verification', date: 'Estimated 2-3 days', done: false, desc: 'District Revenue & Welfare Department review.' },
        { stage: 3, title: 'Departmental Sanction Order', date: 'Pending', done: false, desc: 'Sanction letter issuance by Ministry.' },
        { stage: 4, title: 'DBT Direct Bank Disbursal', date: 'Pending', done: false, desc: `Direct credit to ${formData.bankName} account.` }
      ]
    };

    onApplicationSubmitted(newApp);
    setApplyStep(4); // Success step
  };

  const resetAndClose = () => {
    setActiveTab('details');
    setApplyStep(1);
    setSubmittedAppId(null);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-stoneWarm-950/60 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4 animate-fadeIn">
      <div className="bg-white rounded-3xl border border-stoneWarm-200 shadow-modal max-w-3xl w-full max-h-[90vh] overflow-hidden flex flex-col">
        
        {/* Modal Top Header */}
        <div className="px-6 py-4 border-b border-stoneWarm-200 bg-stoneWarm-50/90 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <span className="w-8 h-8 rounded-lg bg-brand-100 text-brand-700 flex items-center justify-center text-sm font-bold">
              स
            </span>
            <div>
              <span className="text-[11px] font-bold uppercase tracking-wider text-brand-700">
                {scheme.level} Scheme • Code: {scheme.code}
              </span>
              <h2 className="text-base sm:text-lg font-bold text-stoneWarm-900 line-clamp-1">
                {scheme.title}
              </h2>
            </div>
          </div>

          <button
            onClick={resetAndClose}
            className="p-1.5 rounded-full hover:bg-stoneWarm-200 text-stoneWarm-500 hover:text-stoneWarm-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Navigation Tabs */}
        <div className="flex border-b border-stoneWarm-200 bg-white px-6">
          <button
            onClick={() => setActiveTab('details')}
            className={`py-3 px-4 text-xs sm:text-sm font-semibold border-b-2 transition-all ${
              activeTab === 'details'
                ? 'border-brand-600 text-brand-700'
                : 'border-transparent text-stoneWarm-500 hover:text-stoneWarm-800'
            }`}
          >
            Scheme Guidelines & Eligibility
          </button>
          <button
            onClick={() => setActiveTab('apply')}
            className={`py-3 px-4 text-xs sm:text-sm font-semibold border-b-2 transition-all flex items-center space-x-1.5 ${
              activeTab === 'apply'
                ? 'border-brand-600 text-brand-700'
                : 'border-transparent text-stoneWarm-500 hover:text-stoneWarm-800'
            }`}
          >
            <Sparkles className="w-4 h-4 text-ochre-500" />
            <span>Online Application Form</span>
          </button>
        </div>

        {/* Modal Body Content */}
        <div className="p-6 overflow-y-auto flex-1 text-stoneWarm-800 text-sm">
          
          {activeTab === 'details' ? (
            <div className="space-y-6">
              
              {/* Ministry Banner */}
              <div className="flex items-center space-x-3 p-3.5 rounded-xl bg-stoneWarm-100/70 border border-stoneWarm-200/80">
                <Building className="w-5 h-5 text-stoneWarm-600 flex-shrink-0" />
                <div>
                  <p className="text-[11px] font-semibold text-stoneWarm-500 uppercase">Nodal Ministry / Department</p>
                  <p className="text-xs sm:text-sm font-bold text-stoneWarm-900">{scheme.ministry}</p>
                </div>
              </div>

              {/* Benefit Highlight Box */}
              <div className="p-4 rounded-2xl bg-gradient-to-r from-brand-50 to-ochre-50 border border-brand-200/70">
                <div className="flex items-center justify-between">
                  <div>
                    <span className="text-[11px] font-bold uppercase tracking-wider text-brand-800">
                      Direct Entitlement / Benefit
                    </span>
                    <h3 className="text-xl sm:text-2xl font-display font-extrabold text-stoneWarm-900 mt-1">
                      {scheme.benefit}
                    </h3>
                    <p className="text-xs text-stoneWarm-600 mt-0.5 font-medium">
                      {scheme.benefitType}
                    </p>
                  </div>
                  <div className="text-right hidden sm:block">
                    <span className="text-xs text-stoneWarm-500 block">Total Disbursed</span>
                    <span className="text-sm font-bold text-stoneWarm-800">{scheme.totalDisbursed}</span>
                  </div>
                </div>
              </div>

              {/* Description */}
              <div>
                <h4 className="font-bold text-stoneWarm-900 text-xs uppercase tracking-wider mb-2">
                  Detailed Scheme Objectives
                </h4>
                <p className="text-xs sm:text-sm text-stoneWarm-700 leading-relaxed">
                  {scheme.fullDescription}
                </p>
              </div>

              {/* Eligibility Criteria Checklist */}
              <div>
                <h4 className="font-bold text-stoneWarm-900 text-xs uppercase tracking-wider mb-3 flex items-center space-x-1.5">
                  <CheckCircle2 className="w-4 h-4 text-brand-600" />
                  <span>Mandatory Eligibility Criteria</span>
                </h4>
                <div className="bg-stoneWarm-50 rounded-xl p-4 border border-stoneWarm-200 space-y-2.5">
                  {scheme.eligibility.criteria.map((crit, idx) => (
                    <div key={idx} className="flex items-start space-x-2 text-xs sm:text-sm text-stoneWarm-800">
                      <span className="w-4 h-4 rounded-full bg-brand-100 text-brand-700 flex items-center justify-center text-[10px] font-bold mt-0.5 flex-shrink-0">
                        ✓
                      </span>
                      <span>{crit}</span>
                    </div>
                  ))}
                  <div className="pt-2 mt-2 border-t border-stoneWarm-200/80 flex flex-wrap gap-2 text-xs">
                    <span className="bg-white px-2.5 py-1 rounded-md border border-stoneWarm-200 font-medium">
                      Age: {scheme.eligibility.minAge} to {scheme.eligibility.maxAge} Years
                    </span>
                    <span className="bg-white px-2.5 py-1 rounded-md border border-stoneWarm-200 font-medium">
                      Gender: {scheme.eligibility.gender}
                    </span>
                    <span className="bg-white px-2.5 py-1 rounded-md border border-stoneWarm-200 font-medium">
                      Max Annual Income: ₹{(scheme.eligibility.maxIncome).toLocaleString('en-IN')}
                    </span>
                  </div>
                </div>
              </div>

              {/* Required Documents */}
              <div>
                <h4 className="font-bold text-stoneWarm-900 text-xs uppercase tracking-wider mb-3 flex items-center space-x-1.5">
                  <FileText className="w-4 h-4 text-ochre-600" />
                  <span>Required Documents for e-Filing</span>
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  {scheme.documents.map((doc, idx) => (
                    <div key={idx} className="p-2.5 rounded-lg bg-white border border-stoneWarm-200 flex items-center space-x-2 text-xs">
                      <FileText className="w-4 h-4 text-stoneWarm-400 flex-shrink-0" />
                      <span className="font-medium text-stoneWarm-800">{doc}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Action Button */}
              <div className="pt-4 flex justify-end">
                <button
                  onClick={() => setActiveTab('apply')}
                  className="px-6 py-3 rounded-xl bg-brand-600 hover:bg-brand-700 text-white font-semibold text-sm transition-all shadow-subtle flex items-center space-x-2"
                >
                  <span>Proceed to Online Application</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>

            </div>
          ) : (
            // Apply Online Multi-Step Form
            <div>
              {/* Stepper Header */}
              {applyStep < 4 && (
                <div className="flex items-center justify-between mb-6 pb-4 border-b border-stoneWarm-200">
                  <div className="flex items-center space-x-2">
                    <span className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold ${
                      applyStep >= 1 ? 'bg-brand-600 text-white' : 'bg-stoneWarm-200 text-stoneWarm-600'
                    }`}>
                      1
                    </span>
                    <span className="text-xs font-semibold text-stoneWarm-800">Identity & Demographic</span>
                  </div>
                  <div className="h-0.5 flex-1 mx-2 bg-stoneWarm-200"></div>
                  <div className="flex items-center space-x-2">
                    <span className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold ${
                      applyStep >= 2 ? 'bg-brand-600 text-white' : 'bg-stoneWarm-200 text-stoneWarm-600'
                    }`}>
                      2
                    </span>
                    <span className="text-xs font-semibold text-stoneWarm-800">Bank & DBT</span>
                  </div>
                  <div className="h-0.5 flex-1 mx-2 bg-stoneWarm-200"></div>
                  <div className="flex items-center space-x-2">
                    <span className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold ${
                      applyStep >= 3 ? 'bg-brand-600 text-white' : 'bg-stoneWarm-200 text-stoneWarm-600'
                    }`}>
                      3
                    </span>
                    <span className="text-xs font-semibold text-stoneWarm-800">Documents & Consent</span>
                  </div>
                </div>
              )}

              {/* Step 1: Personal & Demographic Info */}
              {applyStep === 1 && (
                <div className="space-y-4">
                  <div className="p-3 bg-brand-50 border border-brand-200 rounded-xl text-xs text-brand-900 flex items-center space-x-2">
                    <ShieldCheck className="w-4 h-4 text-brand-600 flex-shrink-0" />
                    <span>Information auto-synced from citizen DigiLocker profile. You can edit any details below.</span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-semibold text-stoneWarm-700 mb-1">Full Applicant Name</label>
                      <input
                        type="text"
                        value={formData.fullName}
                        onChange={(e) => handleInputChange('fullName', e.target.value)}
                        className="w-full px-3 py-2 rounded-xl bg-stoneWarm-50 border border-stoneWarm-300 text-stoneWarm-900 text-xs focus:ring-1 focus:ring-brand-500"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-stoneWarm-700 mb-1">Aadhaar (Masked)</label>
                      <input
                        type="text"
                        value={formData.aadhaarNumber}
                        disabled
                        className="w-full px-3 py-2 rounded-xl bg-stoneWarm-100 border border-stoneWarm-200 text-stoneWarm-600 text-xs cursor-not-allowed"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-stoneWarm-700 mb-1">Mobile (OTP Linked)</label>
                      <input
                        type="text"
                        value={formData.mobileNumber}
                        onChange={(e) => handleInputChange('mobileNumber', e.target.value)}
                        className="w-full px-3 py-2 rounded-xl bg-stoneWarm-50 border border-stoneWarm-300 text-stoneWarm-900 text-xs focus:ring-1 focus:ring-brand-500"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-stoneWarm-700 mb-1">Social Category</label>
                      <select
                        value={formData.socialCategory}
                        onChange={(e) => handleInputChange('socialCategory', e.target.value)}
                        className="w-full px-3 py-2 rounded-xl bg-stoneWarm-50 border border-stoneWarm-300 text-stoneWarm-900 text-xs focus:ring-1 focus:ring-brand-500"
                      >
                        <option value="General">General</option>
                        <option value="OBC">OBC (Other Backward Class)</option>
                        <option value="SC">SC (Scheduled Caste)</option>
                        <option value="ST">ST (Scheduled Tribe)</option>
                        <option value="EWS">EWS (Economically Weaker Section)</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-stoneWarm-700 mb-1">State & District</label>
                      <input
                        type="text"
                        value={`${formData.district}, ${formData.state}`}
                        onChange={(e) => handleInputChange('state', e.target.value)}
                        className="w-full px-3 py-2 rounded-xl bg-stoneWarm-50 border border-stoneWarm-300 text-stoneWarm-900 text-xs focus:ring-1 focus:ring-brand-500"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-stoneWarm-700 mb-1">Annual Household Income</label>
                      <input
                        type="text"
                        value={formData.annualIncome}
                        onChange={(e) => handleInputChange('annualIncome', e.target.value)}
                        className="w-full px-3 py-2 rounded-xl bg-stoneWarm-50 border border-stoneWarm-300 text-stoneWarm-900 text-xs focus:ring-1 focus:ring-brand-500"
                      />
                    </div>
                  </div>

                  <div className="pt-4 flex justify-between">
                    <button
                      type="button"
                      onClick={() => setActiveTab('details')}
                      className="px-4 py-2 rounded-xl text-xs font-semibold text-stoneWarm-700 hover:bg-stoneWarm-100"
                    >
                      Back to Guidelines
                    </button>
                    <button
                      type="button"
                      onClick={() => setApplyStep(2)}
                      className="px-6 py-2.5 rounded-xl bg-brand-600 hover:bg-brand-700 text-white font-semibold text-xs flex items-center space-x-1.5"
                    >
                      <span>Continue to Bank Details</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              )}

              {/* Step 2: Bank & DBT Information */}
              {applyStep === 2 && (
                <div className="space-y-4">
                  <div className="p-3 bg-ochre-50 border border-ochre-200 rounded-xl text-xs text-ochre-900 flex items-center space-x-2">
                    <CheckCircle2 className="w-4 h-4 text-ochre-600 flex-shrink-0" />
                    <span>Direct Benefit Transfer (DBT) requires an Aadhaar-seeded NPCI mapped bank account.</span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-semibold text-stoneWarm-700 mb-1">Bank Name</label>
                      <input
                        type="text"
                        value={formData.bankName}
                        onChange={(e) => handleInputChange('bankName', e.target.value)}
                        className="w-full px-3 py-2 rounded-xl bg-stoneWarm-50 border border-stoneWarm-300 text-stoneWarm-900 text-xs focus:ring-1 focus:ring-brand-500"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-stoneWarm-700 mb-1">Account Number</label>
                      <input
                        type="text"
                        value={formData.accountNumber}
                        onChange={(e) => handleInputChange('accountNumber', e.target.value)}
                        className="w-full px-3 py-2 rounded-xl bg-stoneWarm-50 border border-stoneWarm-300 text-stoneWarm-900 text-xs focus:ring-1 focus:ring-brand-500"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-stoneWarm-700 mb-1">Bank IFSC Code</label>
                      <input
                        type="text"
                        value={formData.ifscCode}
                        onChange={(e) => handleInputChange('ifscCode', e.target.value)}
                        className="w-full px-3 py-2 rounded-xl bg-stoneWarm-50 border border-stoneWarm-300 text-stoneWarm-900 text-xs focus:ring-1 focus:ring-brand-500 uppercase"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-stoneWarm-700 mb-1">NPCI Aadhaar Mapping Status</label>
                      <div className="px-3 py-2 rounded-xl bg-brand-50 border border-brand-200 text-brand-800 text-xs font-bold flex items-center space-x-1.5">
                        <Check className="w-3.5 h-3.5 text-brand-600" />
                        <span>Active & Verified (Direct DBT Eligible)</span>
                      </div>
                    </div>
                  </div>

                  <div className="pt-4 flex justify-between">
                    <button
                      type="button"
                      onClick={() => setApplyStep(1)}
                      className="px-4 py-2 rounded-xl text-xs font-semibold text-stoneWarm-700 hover:bg-stoneWarm-100 flex items-center space-x-1"
                    >
                      <ArrowLeft className="w-3.5 h-3.5" />
                      <span>Previous Step</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setApplyStep(3)}
                      className="px-6 py-2.5 rounded-xl bg-brand-600 hover:bg-brand-700 text-white font-semibold text-xs flex items-center space-x-1.5"
                    >
                      <span>Continue to Documents</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              )}

              {/* Step 3: Document Locker Sync & Declaration */}
              {applyStep === 3 && (
                <form onSubmit={handleFinalSubmit} className="space-y-4">
                  <div className="p-3 bg-stoneWarm-100 border border-stoneWarm-200 rounded-xl text-xs text-stoneWarm-800">
                    <p className="font-semibold mb-1">Verified Documents Attached Automatically:</p>
                    <div className="space-y-1.5 mt-2">
                      {scheme.documents.map((doc, idx) => (
                        <div key={idx} className="flex items-center justify-between bg-white px-3 py-2 rounded-lg border border-stoneWarm-200">
                          <div className="flex items-center space-x-2 text-xs">
                            <FileText className="w-3.5 h-3.5 text-brand-600" />
                            <span className="font-medium text-stoneWarm-900">{doc}</span>
                          </div>
                          <span className="text-[10px] font-bold text-brand-700 bg-brand-50 px-2 py-0.5 rounded border border-brand-200">
                            Attached via DigiLocker
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="p-3 bg-white border border-stoneWarm-200 rounded-xl">
                    <label className="flex items-start space-x-2 cursor-pointer">
                      <input
                        type="checkbox"
                        required
                        checked={formData.declarationAgreed}
                        onChange={(e) => handleInputChange('declarationAgreed', e.target.checked)}
                        className="mt-0.5 h-4 w-4 text-brand-600 rounded border-stoneWarm-300 focus:ring-brand-500"
                      />
                      <span className="text-xs text-stoneWarm-700 leading-relaxed">
                        I hereby solemnly affirm and declare that the information provided in this application is true and complete to the best of my knowledge and belief. I authorize the nodal department to verify my identity via Aadhaar e-KYC.
                      </span>
                    </label>
                  </div>

                  <div className="pt-4 flex justify-between">
                    <button
                      type="button"
                      onClick={() => setApplyStep(2)}
                      className="px-4 py-2 rounded-xl text-xs font-semibold text-stoneWarm-700 hover:bg-stoneWarm-100 flex items-center space-x-1"
                    >
                      <ArrowLeft className="w-3.5 h-3.5" />
                      <span>Previous Step</span>
                    </button>
                    <button
                      type="submit"
                      className="px-6 py-2.5 rounded-xl bg-brand-600 hover:bg-brand-700 text-white font-semibold text-xs flex items-center space-x-1.5 shadow-card"
                    >
                      <Sparkles className="w-4 h-4 text-ochre-300" />
                      <span>Submit Scheme Application</span>
                    </button>
                  </div>
                </form>
              )}

              {/* Step 4: Submission Success State */}
              {applyStep === 4 && (
                <div className="text-center py-6 space-y-4">
                  <div className="w-16 h-16 rounded-full bg-brand-100 text-brand-700 flex items-center justify-center mx-auto shadow-subtle animate-bounce">
                    <CheckCircle2 className="w-10 h-10" />
                  </div>

                  <div className="max-w-md mx-auto">
                    <span className="text-xs font-bold uppercase tracking-wider text-brand-700 bg-brand-50 px-3 py-1 rounded-full border border-brand-200">
                      Application Lodged Successfully
                    </span>
                    <h3 className="text-xl sm:text-2xl font-bold font-display text-stoneWarm-900 mt-2">
                      Application Submitted!
                    </h3>
                    <p className="text-xs sm:text-sm text-stoneWarm-600 mt-1">
                      Your application for <strong>{scheme.title}</strong> has been transmitted to the District Verification Portal.
                    </p>
                  </div>

                  {/* Application Receipt Box */}
                  <div className="bg-stoneWarm-50 border border-stoneWarm-200 rounded-2xl p-4 max-w-md mx-auto text-left space-y-2 text-xs">
                    <div className="flex justify-between border-b border-stoneWarm-200 pb-2">
                      <span className="text-stoneWarm-500 font-medium">Tracking Reference ID:</span>
                      <strong className="text-stoneWarm-900 font-mono text-sm">{submittedAppId}</strong>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-stoneWarm-500">Applicant:</span>
                      <span className="text-stoneWarm-800 font-semibold">{formData.fullName}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-stoneWarm-500">Entitlement Benefit:</span>
                      <span className="text-brand-700 font-bold">{scheme.benefit}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-stoneWarm-500">DBT Bank Account:</span>
                      <span className="text-stoneWarm-800">{formData.bankName} ({formData.accountNumber})</span>
                    </div>
                  </div>

                  {/* Buttons */}
                  <div className="flex flex-wrap justify-center gap-3 pt-2">
                    <button
                      onClick={() => alert(`Receipt downloaded for ${submittedAppId}`)}
                      className="px-4 py-2 rounded-xl border border-stoneWarm-300 text-stoneWarm-800 hover:bg-stoneWarm-100 text-xs font-semibold flex items-center space-x-1.5"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>Download Receipt (PDF)</span>
                    </button>
                    <button
                      onClick={resetAndClose}
                      className="px-6 py-2 rounded-xl bg-brand-600 hover:bg-brand-700 text-white text-xs font-semibold shadow-subtle"
                    >
                      Done / View in Profile
                    </button>
                  </div>
                </div>
              )}

            </div>
          )}

        </div>

      </div>
    </div>
  );
};
