// SchemeSetu Central Data Repository

export const SCHEMES_DATA = [
  {
    id: 'pm-kisan',
    title: 'PM-KISAN Samman Nidhi',
    code: 'PMKSN-2026',
    ministry: 'Ministry of Agriculture & Farmers Welfare',
    level: 'Central',
    state: 'All India',
    category: 'Agriculture',
    benefit: '₹6,000 / year',
    benefitType: 'Direct Cash Transfer (3 instalments)',
    shortDescription: 'Income support to all landholding farmer families across the country to supplement their financial needs.',
    fullDescription: 'Pradhan Mantri Kisan Samman Nidhi (PM-KISAN) is a Central Sector scheme with 100% funding from the Government of India. Under the scheme, an income support of ₹6,000/- per year in three equal installments is provided to all landholding farmer families.',
    eligibility: {
      minAge: 18,
      maxAge: 75,
      occupation: ['Farmer', 'Agriculture Worker'],
      maxIncome: 500000,
      gender: 'Any',
      caste: ['All', 'General', 'OBC', 'SC', 'ST', 'EWS'],
      criteria: [
        'Must possess cultivable landholding in applicant\'s name',
        'Valid Aadhaar linked with operational bank account (NPCI mapped)',
        'Not paying income tax in previous assessment year',
        'Not holding institutional or constitutional government posts'
      ]
    },
    documents: ['Aadhaar Card', 'Land Record (Khatauni / Patta)', 'Bank Passbook / Cancelled Cheque', 'Self-Declaration Form'],
    popularity: 98,
    active: true,
    totalDisbursed: '₹3.2 Lakh Cr',
    beneficiariesCount: '11.8 Crore'
  },
  {
    id: 'pm-ayushman',
    title: 'Ayushman Bharat (PM-JAY)',
    code: 'AB-PMJAY',
    ministry: 'Ministry of Health and Family Welfare',
    level: 'Central',
    state: 'All India',
    category: 'Healthcare',
    benefit: '₹5,00,000 / family / year',
    benefitType: 'Cashless Hospitalization Cover',
    shortDescription: 'World\'s largest government-funded healthcare scheme providing secondary and tertiary care hospitalization.',
    fullDescription: 'Ayushman Bharat PM-JAY offers cashless and paperless access to healthcare services for the beneficiary at the point of service in any empanelled public or private hospital across India.',
    eligibility: {
      minAge: 0,
      maxAge: 100,
      occupation: ['Any', 'Informal Worker', 'Farmer', 'Daily Wage Earner'],
      maxIncome: 300000,
      gender: 'Any',
      caste: ['All', 'OBC', 'SC', 'ST', 'EWS'],
      criteria: [
        'Listed in SECC 2011 deprivation criteria or State Ration Database',
        'Households without adult member between age 16-59',
        'Families living in one-room kutcha houses',
        'Landless manual casual labor households'
      ]
    },
    documents: ['Aadhaar Card', 'Ration Card / Family ID', 'Mobile Number linked with OTP'],
    popularity: 96,
    active: true,
    totalDisbursed: '₹84,000 Cr',
    beneficiariesCount: '55 Crore Citizens'
  },
  {
    id: 'pm-awas-gramin',
    title: 'Pradhan Mantri Awas Yojana (PMAY-G)',
    code: 'PMAY-G-2026',
    ministry: 'Ministry of Rural Development',
    level: 'Central',
    state: 'All India',
    category: 'Housing',
    benefit: '₹1,20,000 - ₹1,30,000',
    benefitType: 'Direct Pucca House Construction Grant',
    shortDescription: 'Financial assistance for construction of quality pucca houses with basic amenities for homeless rural families.',
    fullDescription: 'PMAY-Gramin provides monetary assistance directly to beneficiaries\' accounts in stages linked with geo-tagged construction milestones, along with 90 days of MGNREGA wage support.',
    eligibility: {
      minAge: 18,
      maxAge: 70,
      occupation: ['Any', 'Rural Laborer', 'Farmer'],
      maxIncome: 200000,
      gender: 'Any',
      caste: ['All', 'SC', 'ST', 'OBC', 'Minority', 'EWS'],
      criteria: [
        'Must not own any pucca house anywhere in India',
        'Should not possess motorized 3/4 wheeler vehicle',
        'Monthly income of earning member less than ₹15,000'
      ]
    },
    documents: ['Aadhaar Card', 'BPL Ration Card / SECC Tin No', 'Bank Account Details', 'Site Photo / Land Consent'],
    popularity: 92,
    active: true,
    totalDisbursed: '₹2.8 Lakh Cr',
    beneficiariesCount: '2.95 Crore Houses'
  },
  {
    id: 'pm-mudra',
    title: 'Pradhan Mantri MUDRA Yojana',
    code: 'PMMY-LOAN',
    ministry: 'Ministry of Finance & MSME',
    level: 'Central',
    state: 'All India',
    category: 'MSME & Business',
    benefit: 'Up to ₹20,00,000 Loan',
    benefitType: 'Collateral-free subsidized business credit',
    shortDescription: 'Refinance support to micro and small enterprises for non-farm income generating activities.',
    fullDescription: 'MUDRA provides loans under three categories: Shishu (up to ₹50,000), Kishore (₹50,000 to ₹5 Lakh), and Tarun (₹5 Lakh to ₹20 Lakh) without requiring collateral security.',
    eligibility: {
      minAge: 18,
      maxAge: 65,
      occupation: ['Self Employed', 'Artisan', 'Shopkeeper', 'Trader', 'Manufacturer'],
      maxIncome: 2500000,
      gender: 'Any',
      caste: ['All'],
      criteria: [
        'Indian Citizen with viable non-farm business proposal',
        'No prior loan default record with any commercial bank',
        'Existing or prospective enterprise registration'
      ]
    },
    documents: ['Aadhaar & PAN Card', 'Proof of Business Address / Udyam', '6 Months Bank Statement', 'Project Quotation / Plan'],
    popularity: 91,
    active: true,
    totalDisbursed: '₹24 Lakh Cr',
    beneficiariesCount: '48 Crore Loans'
  },
  {
    id: 'nsp-post-matric',
    title: 'Post-Matric Scholarship for Higher Education',
    code: 'NSP-PMS-2026',
    ministry: 'Ministry of Social Justice & Empowerment',
    level: 'Central',
    state: 'All India',
    category: 'Education',
    benefit: '₹15,000 - ₹50,000 / year',
    benefitType: 'Full Tuition Fee Reimbursement + Maintenance Allowance',
    shortDescription: 'Financial scholarship to support meritorious students from disadvantaged backgrounds through college/university.',
    fullDescription: 'Provides 100% financial assistance including tuition fee waiver and monthly stipend to students pursuing graduate, post-graduate, and professional technical diplomas/degrees.',
    eligibility: {
      minAge: 16,
      maxAge: 32,
      occupation: ['Student'],
      maxIncome: 250000,
      gender: 'Any',
      caste: ['SC', 'ST', 'OBC', 'EWS', 'Minority'],
      criteria: [
        'Passed Class 10/12 or undergraduate exam with at least 50% marks',
        'Enrolled in a recognized college / institute / university',
        'Family annual income not exceeding ₹2.5 Lakh'
      ]
    },
    documents: ['Aadhaar Card', 'Income Certificate issued by Tehsildar', 'Caste Certificate', 'Previous Year Marksheet', 'College Admission Fee Receipt'],
    popularity: 89,
    active: true,
    totalDisbursed: '₹18,500 Cr',
    beneficiariesCount: '65 Lakh Students'
  },
  {
    id: 'pm-sukanya-samriddhi',
    title: 'Sukanya Samriddhi Yojana (Beti Bachao)',
    code: 'SSY-GOV',
    ministry: 'Ministry of Women & Child Development',
    level: 'Central',
    state: 'All India',
    category: 'Women & Child',
    benefit: '8.2% Compound Interest + Tax Free',
    benefitType: 'High-Yield Girl Child Savings Scheme',
    shortDescription: 'Government-backed savings scheme for girl children ensuring funds for higher education and marriage.',
    fullDescription: 'Enables parents to open a dedicated savings account with guaranteed 8.2% sovereign interest rate and 100% triple tax exemption under Section 80C with flexible deposits.',
    eligibility: {
      minAge: 0,
      maxAge: 10,
      occupation: ['Any', 'Student'],
      maxIncome: 10000000,
      gender: 'Female',
      caste: ['All'],
      criteria: [
        'Girl child below the age of 10 years at account opening',
        'Maximum 2 accounts per family (one for each girl child)'
      ]
    },
    documents: ['Girl Child Birth Certificate', 'Guardian Aadhaar & PAN Card', 'Address Proof', 'Passport Photo'],
    popularity: 88,
    active: true,
    totalDisbursed: '₹1.2 Lakh Cr',
    beneficiariesCount: '3.4 Crore Accounts'
  },
  {
    id: 'pm-vishwakarma',
    title: 'PM Vishwakarma Kaushal Samman',
    code: 'PM-VISHWA-2026',
    ministry: 'Ministry of Skill Development & MSME',
    level: 'Central',
    state: 'All India',
    category: 'Skill & MSME',
    benefit: '₹15,000 Toolkit + ₹3 Lakh 5% Loan',
    benefitType: 'Skill Certification, Modern Toolkits & Low Interest Credit',
    shortDescription: 'End-to-end support for traditional artisans and craftspeople across 18 traditional trades.',
    fullDescription: 'Comprehensive package providing recognized Vishwakarma Certificate & ID, ₹500/day training stipend, ₹15,000 digital e-voucher for modern toolkits, and collateral-free enterprise loan at 5% interest.',
    eligibility: {
      minAge: 18,
      maxAge: 65,
      occupation: ['Artisan', 'Carpenter', 'Blacksmith', 'Potter', 'Mason', 'Tailor', 'Weaver', 'Cobbler', 'Sculptor'],
      maxIncome: 300000,
      gender: 'Any',
      caste: ['All'],
      criteria: [
        'Engaged in one of the 18 identified traditional family trades',
        'Should not have availed benefits under PMEGP or MUDRA in last 5 years',
        'Only one member per family eligible'
      ]
    },
    documents: ['Aadhaar Card', 'Trade Verification Slip by Gram Panchayat/ULB', 'Bank Passbook', 'Active Mobile Number'],
    popularity: 94,
    active: true,
    totalDisbursed: '₹13,000 Cr',
    beneficiariesCount: '25 Lakh Artisans'
  },
  {
    id: 'atal-pension',
    title: 'Atal Pension Yojana (APY)',
    code: 'APY-PFRDA',
    ministry: 'Ministry of Finance & PFRDA',
    level: 'Central',
    state: 'All India',
    category: 'Social Security',
    benefit: '₹1,000 - ₹5,000 / month Guaranteed Pension',
    benefitType: 'Lifelong Monthly Pension post 60 years',
    shortDescription: 'Guaranteed government-backed pension scheme for unorganized sector workers.',
    fullDescription: 'Administered by PFRDA, subscribers receive a guaranteed minimum monthly pension ranging from ₹1,000 to ₹5,000 from the age of 60 years based on monthly contribution.',
    eligibility: {
      minAge: 18,
      maxAge: 40,
      occupation: ['Any', 'Unorganized Worker', 'Self Employed', 'Driver', 'House Help'],
      maxIncome: 400000,
      gender: 'Any',
      caste: ['All'],
      criteria: [
        'Indian Citizen aged between 18 and 40 years',
        'Must have savings bank account with auto-debit facility',
        'Should not be an income taxpayer'
      ]
    },
    documents: ['Aadhaar Card', 'Bank Account Details', 'Nominee Information'],
    popularity: 87,
    active: true,
    totalDisbursed: '₹36,000 Cr',
    beneficiariesCount: '6.2 Crore Subscribers'
  },
  {
    id: 'pm-surya-ghar',
    title: 'PM Surya Ghar: Muft Bijli Yojana',
    code: 'PMSURYA-2026',
    ministry: 'Ministry of New and Renewable Energy',
    level: 'Central',
    state: 'All India',
    category: 'Energy & Housing',
    benefit: 'Up to ₹78,000 Direct Subsidy + 300 Units Free Electricity',
    benefitType: 'Rooftop Solar Installation Capital Subsidy',
    shortDescription: 'Subsidized rooftop solar power installation for 1 crore households across India.',
    fullDescription: 'Provides up to 60% direct subsidy on residential rooftop solar power systems up to 3kW capacity, slashing household electricity bills to zero and allowing surplus power export.',
    eligibility: {
      minAge: 21,
      maxAge: 75,
      occupation: ['Any'],
      maxIncome: 1200000,
      gender: 'Any',
      caste: ['All'],
      criteria: [
        'Applicant must own residential property with suitable unshaded roof',
        'Valid grid electricity connection in applicant\'s name',
        'No prior subsidy availed for solar rooftop at same meter'
      ]
    },
    documents: ['Electricity Bill of past 6 months', 'Aadhaar Card', 'Property Ownership Proof / Registry', 'Bank Cancelled Cheque'],
    popularity: 95,
    active: true,
    totalDisbursed: '₹75,000 Cr',
    beneficiariesCount: '1 Crore Target'
  },
  {
    id: 'ladli-behna-mp',
    title: 'Mukhyamantri Ladli Behna Yojana',
    code: 'MP-LBY-2026',
    ministry: 'Women & Child Development (Madhya Pradesh)',
    level: 'State',
    state: 'Madhya Pradesh',
    category: 'Women & Child',
    benefit: '₹1,250 / month (₹15,000 / year)',
    benefitType: 'Direct DBT to Women Bank Accounts',
    shortDescription: 'Monthly financial assistance to married, widowed, and divorced women to empower self-reliance and nutrition.',
    fullDescription: 'State welfare scheme transferring ₹1,250 on the 10th of every month directly into the Aadhaar-linked DBT bank account of women aged 21-60 years residing in Madhya Pradesh.',
    eligibility: {
      minAge: 21,
      maxAge: 60,
      occupation: ['Homemaker', 'Self-Employed', 'Worker'],
      maxIncome: 250000,
      gender: 'Female',
      caste: ['All'],
      criteria: [
        'Permanent Resident of Madhya Pradesh',
        'Married / Divorced / Widowed / Abandoned woman',
        'Family annual income strictly less than ₹2.5 Lakh',
        'No family member paying income tax or holding government job'
      ]
    },
    documents: ['Samagra Family & Member ID', 'Aadhaar Card with e-KYC', 'DBT Enabled Bank Account Passbook'],
    popularity: 99,
    active: true,
    totalDisbursed: '₹22,000 Cr',
    beneficiariesCount: '1.29 Crore Women'
  },
  {
    id: 'gruha-lakshmi-ka',
    title: 'Gruha Lakshmi Scheme',
    code: 'KA-GLS-2026',
    ministry: 'Women & Child Development (Karnataka)',
    level: 'State',
    state: 'Karnataka',
    category: 'Women & Child',
    benefit: '₹2,000 / month (₹24,000 / year)',
    benefitType: 'Direct Monthly DBT for Woman Head of Household',
    shortDescription: 'Guaranteed ₹2,000 per month financial aid for female heads of families in Karnataka.',
    fullDescription: 'Providing monthly financial support directly to the female head of family listed in BPL/APL/Antyodaya ration cards to assist with daily household expenses and dignity.',
    eligibility: {
      minAge: 18,
      maxAge: 70,
      occupation: ['Any', 'Homemaker'],
      maxIncome: 300000,
      gender: 'Female',
      caste: ['All'],
      criteria: [
        'Permanent Resident of Karnataka',
        'Must be recognized as Head of Family on Ration Card',
        'Applicant or spouse should not be GST/Income tax payees'
      ]
    },
    documents: ['Karnataka Ration Card (BPL/APL)', 'Aadhaar Card', 'Aadhaar Linked Bank Passbook'],
    popularity: 97,
    active: true,
    totalDisbursed: '₹28,500 Cr',
    beneficiariesCount: '1.18 Crore Women'
  },
  {
    id: 'kisan-credit-card',
    title: 'Kisan Credit Card (KCC) Scheme',
    code: 'KCC-NABARD',
    ministry: 'Ministry of Agriculture & NABARD',
    level: 'Central',
    state: 'All India',
    category: 'Agriculture',
    benefit: 'Up to ₹3,00,000 at 4% Interest',
    benefitType: 'Subsidized Short-Term Agricultural Working Capital',
    shortDescription: 'Timely credit support to farmers for crop cultivation, post-harvest expenses, and allied dairy/fisheries.',
    fullDescription: 'Provides revolving cash credit with an effective interest rate of only 4% (upon timely repayment) with flexible withdrawal and repayment cycles tailored to harvesting seasons.',
    eligibility: {
      minAge: 18,
      maxAge: 75,
      occupation: ['Farmer', 'Dairy Farmer', 'Fisherman', 'Sharecropper'],
      maxIncome: 1000000,
      gender: 'Any',
      caste: ['All'],
      criteria: [
        'Owner cultivators or tenant farmers / oral lessees / sharecroppers',
        'Self Help Groups (SHGs) or Joint Liability Groups (JLGs) of farmers'
      ]
    },
    documents: ['Land Title Deed / Record of Rights (7/12 or Khatauni)', 'Aadhaar Card & PAN', 'Passport Photographs'],
    popularity: 90,
    active: true,
    totalDisbursed: '₹9.4 Lakh Cr',
    beneficiariesCount: '7.3 Crore Farmers'
  }
];

export const CATEGORIES = [
  { id: 'all', name: 'All Schemes', count: 12, icon: 'LayoutGrid' },
  { id: 'Agriculture', name: 'Agriculture & Farmers', count: 3, icon: 'Sprout' },
  { id: 'Healthcare', name: 'Healthcare & Insurance', count: 1, icon: 'HeartPulse' },
  { id: 'Women & Child', name: 'Women & Child Welfare', count: 3, icon: 'Users' },
  { id: 'Education', name: 'Education & Scholarships', count: 1, icon: 'GraduationCap' },
  { id: 'Housing', name: 'Housing & Urban', count: 2, icon: 'Home' },
  { id: 'MSME & Business', name: 'MSME & Self-Employment', count: 2, icon: 'Briefcase' },
  { id: 'Social Security', name: 'Pension & Social Security', count: 1, icon: 'ShieldCheck' },
];

export const INITIAL_APPLICATIONS = [
  {
    id: 'SS-2026-89412',
    schemeId: 'pm-kisan',
    schemeTitle: 'PM-KISAN Samman Nidhi',
    applicantName: 'Rajesh Kumar Verma',
    aadhaarMasked: 'XXXX-XXXX-4819',
    category: 'OBC',
    appliedDate: '2026-08-14',
    status: 'Approved',
    currentStage: 3,
    disbursedAmount: '₹6,000 / yr',
    nextInstallmentDate: '2026-09-15',
    officerRemarks: 'Land Patta verified by Tehsildar Office. NPCI mapper active.',
    timeline: [
      { stage: 1, title: 'Application Submitted Online', date: '14 Aug 2026, 11:20 AM', done: true, desc: 'Application ref SS-2026-89412 generated with Aadhaar e-KYC.' },
      { stage: 2, title: 'Document & Land Record Verification', date: '18 Aug 2026, 03:45 PM', done: true, desc: 'District Revenue Officer cleared Khatauni 418/2.' },
      { stage: 3, title: 'Sanction Order Issued', date: '24 Aug 2026, 05:10 PM', done: true, desc: 'Sanction letter generated by Ministry of Agriculture.' },
      { stage: 4, title: 'DBT Bank Disbursal', date: 'Scheduled for 15 Sep 2026', done: false, desc: 'Pending batch trigger to SBI A/c ending in 4102.' }
    ]
  },
  {
    id: 'SS-2026-77341',
    schemeId: 'pm-surya-ghar',
    schemeTitle: 'PM Surya Ghar: Muft Bijli Yojana',
    applicantName: 'Rajesh Kumar Verma',
    aadhaarMasked: 'XXXX-XXXX-4819',
    category: 'General/OBC',
    appliedDate: '2026-08-20',
    status: 'Under Review',
    currentStage: 2,
    disbursedAmount: '₹78,000 Subsidy',
    officerRemarks: 'Technical feasibility check scheduled with DISCOM engineer.',
    timeline: [
      { stage: 1, title: 'Application Submitted Online', date: '20 Aug 2026, 02:15 PM', done: true, desc: 'Electricity CA number 10098273 linked.' },
      { stage: 2, title: 'DISCOM Site Feasibility & Meter Check', date: '25 Aug 2026, 10:00 AM', done: true, desc: 'Technical inspection passed for 3kW rooftop plant.' },
      { stage: 3, title: 'Vendor Quotation & Net Meter Sanction', date: 'In Progress', done: false, desc: 'Awaiting empaneled vendor contract agreement upload.' },
      { stage: 4, title: 'Direct Subsidy Credit to Account', date: 'Pending completion', done: false, desc: '₹78,000 DBT release within 30 days of commissioning.' }
    ]
  },
  {
    id: 'SS-2026-61904',
    schemeId: 'pm-vishwakarma',
    schemeTitle: 'PM Vishwakarma Kaushal Samman',
    applicantName: 'Sunita Devi Sharma',
    aadhaarMasked: 'XXXX-XXXX-7128',
    category: 'EWS',
    appliedDate: '2026-08-22',
    status: 'Documents Required',
    currentStage: 1,
    disbursedAmount: '₹15,000 Toolkit + Loan',
    officerRemarks: 'Gram Panchayat trade certification seal missing. Please re-upload verified letter.',
    timeline: [
      { stage: 1, title: 'Application Submitted Online', date: '22 Aug 2026, 04:30 PM', done: true, desc: 'Initial trade registration for Tailor category.' },
      { stage: 2, title: 'Panchayat / Urban Local Body Endorsement', date: 'Action Needed', done: false, desc: 'Panchayat Pradhan trade verification certificate required.' },
      { stage: 3, title: 'Basic Skill Training & Toolkit Voucher', date: 'Pending', done: false, desc: '5-day skill training slot allocation.' },
      { stage: 4, title: 'Enterprise Loan Sanction', date: 'Pending', done: false, desc: '5% interest loan up to ₹1 Lakh.' }
    ]
  },
  {
    id: 'SS-2026-55109',
    schemeId: 'pm-ayushman',
    schemeTitle: 'Ayushman Bharat (PM-JAY)',
    applicantName: 'Anil Prakash Yadav',
    aadhaarMasked: 'XXXX-XXXX-3391',
    category: 'OBC',
    appliedDate: '2026-08-10',
    status: 'Disbursed',
    currentStage: 4,
    disbursedAmount: '₹5,00,000 Card Issued',
    officerRemarks: 'Ayushman Golden Card generated and sent via DigiLocker.',
    timeline: [
      { stage: 1, title: 'Ration Database Match Found', date: '10 Aug 2026', done: true, desc: 'SECC Household record validated.' },
      { stage: 2, title: 'Biometric / OTP e-KYC Verification', date: '11 Aug 2026', done: true, desc: 'Aadhaar e-KYC passed with 100% match.' },
      { stage: 3, title: 'Card Approval from State Health Authority', date: '12 Aug 2026', done: true, desc: 'Policy active across 28,000 empanelled hospitals.' },
      { stage: 4, title: 'Ayushman Golden Card Active', date: '12 Aug 2026', done: true, desc: 'Card Ready for instant cashless hospitalization.' }
    ]
  }
];

export const MOCK_USER_PROFILE = {
  name: 'Rajesh Kumar Verma',
  email: 'rajesh.verma@example.in',
  phone: '+91 98765 43210',
  role: 'citizen',
  avatarInitials: 'RV',
  aadhaarNumber: 'XXXX-XXXX-4819',
  dob: '1992-04-15',
  gender: 'Male',
  age: 34,
  state: 'Madhya Pradesh',
  district: 'Indore',
  pincode: '452001',
  category: 'OBC',
  occupation: 'Small Scale Farmer / Agriculture',
  annualIncome: '₹ 2,40,000',
  annualIncomeNumeric: 240000,
  hasLandholding: true,
  landAreaAcres: '2.5 Acres',
  rationCardType: 'BPL (Below Poverty Line)',
  bankName: 'State Bank of India',
  accountNumber: '••••••••4102',
  ifscCode: 'SBIN0001842',
  npciMapped: true,
  documentsLocker: [
    { id: 'doc-1', name: 'Aadhaar Card (e-KYC)', type: 'National ID', status: 'Verified', date: '2026-01-12', size: '1.2 MB', verifiedBy: 'UIDAI Direct API' },
    { id: 'doc-2', name: 'Khasra / Khatauni Land Record (Patta)', type: 'Land Ownership', status: 'Verified', date: '2026-03-05', size: '2.4 MB', verifiedBy: 'MP Bhulekh Revenue Portal' },
    { id: 'doc-3', name: 'Annual Income Certificate (Tehsildar)', type: 'Income Proof', status: 'Verified', date: '2026-06-18', size: '890 KB', verifiedBy: 'District Magistrate Office' },
    { id: 'doc-4', name: 'BPL Ration Card Copy', type: 'Family Card', status: 'Verified', date: '2025-11-20', size: '1.8 MB', verifiedBy: 'Food & Civil Supplies Dept' },
    { id: 'doc-5', name: 'Bank Passbook & Cancelled Cheque', type: 'Banking & DBT', status: 'Verified', date: '2026-02-14', size: '950 KB', verifiedBy: 'SBI Branch IFSC Check' }
  ]
};

export const ADMIN_ANALYTICS = {
  totalApplications: 148290,
  approvedCount: 124800,
  underReviewCount: 18450,
  rejectedCount: 5040,
  totalDisbursedCr: '₹ 482.60 Cr',
  activeSchemesCount: 12,
  citizenSatisfactionRate: '96.4%',
  recentActivity: [
    { time: '2 mins ago', text: 'Auto-verified 142 Aadhaar KYC records for PM-KISAN 17th Tranche.' },
    { time: '18 mins ago', text: 'Sanction order batch #891 (₹ 14.8 Cr) cleared for Direct Benefit Transfer.' },
    { time: '1 hour ago', text: 'New State Scheme "Gruha Lakshmi 2.0" added to discovery catalog.' },
    { time: '3 hours ago', text: 'System resolved 48 citizen grievance tickets.' }
  ]
};
