import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { HeroSection } from './components/HeroSection';
import { SchemeCatalog } from './components/SchemeCatalog';
import { SchemeDetailsModal } from './components/SchemeDetailsModal';
import { EligibilityCalculator } from './components/EligibilityCalculator';
import { TrackApplicationWidget } from './components/TrackApplicationWidget';
import { ProfileView } from './components/ProfileView';
import { AdminDashboard } from './components/AdminDashboard';
import { FAQSection } from './components/FAQSection';
import { GrievanceModal } from './components/GrievanceModal';
import { Footer } from './components/Footer';
import { SCHEMES_DATA, INITIAL_APPLICATIONS, MOCK_USER_PROFILE } from './data/mockData';
import { User, ShieldCheck, Sparkles, FileText, LayoutDashboard, Layers } from 'lucide-react';

export function App() {
  const [activeView, setActiveView] = useState('home'); // 'home', 'calculator', 'tracker', 'profile', 'admin'
  const [user, setUser] = useState(MOCK_USER_PROFILE); // Start with active citizen demo session
  const [schemes, setSchemes] = useState(SCHEMES_DATA);
  const [applications, setApplications] = useState(INITIAL_APPLICATIONS);

  // Search & Filter State
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [selectedLanguage, setSelectedLanguage] = useState('en');

  // Modals
  const [selectedSchemeForModal, setSelectedSchemeForModal] = useState(null);
  const [authModalOpen, setAuthModalOpen] = useState(false);
  const [authMode, setAuthMode] = useState('login');
  const [grievanceModalOpen, setGrievanceModalOpen] = useState(false);

  // Scroll to top on view changes
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [activeView]);

  const handleOpenAuth = (mode = 'login') => {
    setAuthMode(mode);
    setAuthModalOpen(true);
  };

  const handleLogout = () => {
    setUser(null);
    setActiveView('home');
    alert('You have been signed out.');
  };

  const handleLoginSuccess = (newUser) => {
    setUser(newUser);
    if (newUser.role === 'admin' || newUser.role === 'officer') {
      setActiveView('admin');
    } else {
      setActiveView('profile');
    }
  };

  const handleApplicationSubmitted = (newApp) => {
    setApplications(prev => [newApp, ...prev]);
  };

  const handleQuickApply = (scheme) => {
    setSelectedSchemeForModal(scheme);
  };

  const handleTrackFromProfile = (appId) => {
    setActiveView('tracker');
  };

  return (
    <div className="min-h-screen bg-stoneWarm-50 text-stoneWarm-900 flex flex-col font-sans selection:bg-brand-100 selection:text-brand-900">
      
      {/* Top Navigation */}
      <Navbar
        activeView={activeView}
        setActiveView={setActiveView}
        user={user}
        onOpenAuth={handleOpenAuth}
        onLogout={handleLogout}
        onOpenGrievance={() => setGrievanceModalOpen(true)}
        selectedLanguage={selectedLanguage}
        setSelectedLanguage={setSelectedLanguage}
      />

      {/* Main View Router */}
      <main className="flex-1">
        {activeView === 'home' && (
          <>
            <HeroSection
              searchQuery={searchQuery}
              setSearchQuery={setSearchQuery}
              onStartCalculator={() => setActiveView('calculator')}
              onStartTracker={() => setActiveView('tracker')}
              onSelectCategory={(cat) => {
                setSelectedCategory(cat);
                const el = document.getElementById('schemes-catalog');
                if (el) el.scrollIntoView({ behavior: 'smooth' });
              }}
            />

            <SchemeCatalog
              schemes={schemes}
              searchQuery={searchQuery}
              setSearchQuery={setSearchQuery}
              selectedCategory={selectedCategory}
              setSelectedCategory={setSelectedCategory}
              onOpenSchemeDetails={(scheme) => setSelectedSchemeForModal(scheme)}
              onQuickApply={handleQuickApply}
            />

            <FAQSection onOpenGrievance={() => setGrievanceModalOpen(true)} />
          </>
        )}

        {activeView === 'calculator' && (
          <EligibilityCalculator
            onApplyScheme={(scheme) => setSelectedSchemeForModal(scheme)}
          />
        )}

        {activeView === 'tracker' && (
          <TrackApplicationWidget
            applications={applications}
            onOpenDetails={(scheme) => setSelectedSchemeForModal(scheme)}
          />
        )}

        {activeView === 'profile' && (
          <ProfileView
            user={user || MOCK_USER_PROFILE}
            setUser={setUser}
            applications={applications}
            onTrackApp={handleTrackFromProfile}
            onApplyScheme={handleQuickApply}
          />
        )}

        {activeView === 'admin' && (
          <AdminDashboard
            schemes={schemes}
            setSchemes={setSchemes}
            applications={applications}
            setApplications={setApplications}
            user={user}
          />
        )}
      </main>

      {/* Modals */}
      <SchemeDetailsModal
        scheme={selectedSchemeForModal}
        isOpen={!!selectedSchemeForModal}
        onClose={() => setSelectedSchemeForModal(null)}
        user={user}
        onApplicationSubmitted={handleApplicationSubmitted}
      />

      {/* Lazy Auth Modal Import / Container */}
      <AuthModalWrapper
        isOpen={authModalOpen}
        onClose={() => setAuthModalOpen(false)}
        initialMode={authMode}
        onLoginSuccess={handleLoginSuccess}
      />

      <GrievanceModal
        isOpen={grievanceModalOpen}
        onClose={() => setGrievanceModalOpen(false)}
      />

      {/* Official Footer */}
      <Footer
        onOpenGrievance={() => setGrievanceModalOpen(true)}
        onStartCalculator={() => setActiveView('calculator')}
        onStartTracker={() => setActiveView('tracker')}
        setActiveView={setActiveView}
      />

      {/* Quick Role & View Floating Bar (Demo Convenience) */}
      <div className="fixed bottom-4 left-1/2 -translate-x-1/2 z-40 bg-stoneWarm-900/90 text-stoneWarm-200 backdrop-blur-md px-4 py-2 rounded-full border border-stoneWarm-700 shadow-modal flex items-center space-x-2 text-xs font-semibold">
        <span className="text-ochre-400 font-bold hidden sm:inline mr-1">Quick Switch:</span>
        <button
          onClick={() => setActiveView('home')}
          className={`px-3 py-1 rounded-full transition-all ${
            activeView === 'home' ? 'bg-brand-600 text-white font-bold' : 'hover:bg-stoneWarm-800'
          }`}
        >
          Schemes
        </button>
        <button
          onClick={() => setActiveView('calculator')}
          className={`px-3 py-1 rounded-full transition-all ${
            activeView === 'calculator' ? 'bg-brand-600 text-white font-bold' : 'hover:bg-stoneWarm-800'
          }`}
        >
          Eligibility
        </button>
        <button
          onClick={() => setActiveView('tracker')}
          className={`px-3 py-1 rounded-full transition-all ${
            activeView === 'tracker' ? 'bg-brand-600 text-white font-bold' : 'hover:bg-stoneWarm-800'
          }`}
        >
          Track
        </button>
        <button
          onClick={() => setActiveView('profile')}
          className={`px-3 py-1 rounded-full transition-all ${
            activeView === 'profile' ? 'bg-brand-600 text-white font-bold' : 'hover:bg-stoneWarm-800'
          }`}
        >
          Profile
        </button>
        <button
          onClick={() => setActiveView('admin')}
          className={`px-3 py-1 rounded-full transition-all ${
            activeView === 'admin' ? 'bg-brand-600 text-white font-bold' : 'hover:bg-stoneWarm-800'
          }`}
        >
          Admin Portal
        </button>
      </div>

    </div>
  );
}

// Wrapper for Auth Modal
import { AuthModal } from './components/AuthModal';
function AuthModalWrapper(props) {
  return <AuthModal {...props} />;
}

export default App;
